export interface Theme {
  id: string; name: string;
  night: string[];   // 950, 900, 850, 800, 700
  crimson: string[]; // 300, 400, 500, 600, 700  (رنگ اصلی)
  flame: string[];   // 300, 400, 500, 600       (رنگ مکمل)
  ink: string;       // رنگ متن روی رنگ اصلی
}

export const THEMES: Theme[] = [
  { id: "fire", name: "مخمل", night: ["#09070a", "#100c0f", "#150f13", "#1b1318", "#271b22"], crimson: ["#ff98a5", "#f0586d", "#d9263f", "#b81c33", "#8f1226"], flame: ["#ffe2a3", "#f7c96a", "#f0b13e", "#d9962a"], ink: "#ffffff" },
  { id: "ocean", name: "اقیانوس", night: ["#05080f", "#08101c", "#0b1524", "#0f1b2e", "#16253d"], crimson: ["#93c5fd", "#60a5fa", "#3b82f6", "#2563eb", "#1d4ed8"], flame: ["#a5f3fc", "#67e8f9", "#22d3ee", "#06b6d4"], ink: "#ffffff" },
  { id: "forest", name: "جنگل", night: ["#050a07", "#08120c", "#0b1710", "#0f1d15", "#17291e"], crimson: ["#86efac", "#4ade80", "#22c55e", "#16a34a", "#15803d"], flame: ["#d9f99d", "#bef264", "#a3e635", "#84cc16"], ink: "#052e16" },
  { id: "violet", name: "بنفشه", night: ["#08060f", "#0e0a1a", "#130e22", "#18122b", "#241a3d"], crimson: ["#d8b4fe", "#c084fc", "#a855f7", "#9333ea", "#7e22ce"], flame: ["#fbcfe8", "#f9a8d4", "#f472b6", "#ec4899"], ink: "#ffffff" },
  { id: "gold", name: "طلا", night: ["#0a0805", "#12100a", "#17140d", "#1d1911", "#2b2519"], crimson: ["#fde68a", "#fcd34d", "#f59e0b", "#d97706", "#b45309"], flame: ["#fef08a", "#fde047", "#facc15", "#eab308"], ink: "#1c1304" },
  { id: "neon", name: "نئون", night: ["#07060d", "#0d0a16", "#120e1f", "#17122a", "#221a3b"], crimson: ["#ff9ccb", "#ff5fae", "#ff2d95", "#e11d77", "#be125f"], flame: ["#a5f3fc", "#67e8f9", "#22d3ee", "#06b6d4"], ink: "#ffffff" },
  { id: "sunset", name: "غروب", night: ["#0a0706", "#130d0b", "#18110e", "#1e1612", "#2b1f19"], crimson: ["#fdba74", "#fb923c", "#f97316", "#ea580c", "#c2410c"], flame: ["#fbcfe8", "#f9a8d4", "#f472b6", "#ec4899"], ink: "#1f0d03" },
  { id: "mint", name: "نعنا", night: ["#050a0a", "#081212", "#0b1717", "#0f1d1d", "#172a2a"], crimson: ["#5eead4", "#2dd4bf", "#14b8a6", "#0d9488", "#0f766e"], flame: ["#bbf7d0", "#86efac", "#4ade80", "#22c55e"], ink: "#04201d" },
  { id: "rose", name: "گل‌سرخ", night: ["#0b0709", "#140c10", "#190f14", "#20141a", "#2e1d25"], crimson: ["#fda4af", "#fb7185", "#f43f5e", "#e11d48", "#be123c"], flame: ["#fed7aa", "#fdba74", "#fb923c", "#f97316"], ink: "#ffffff" },
  { id: "midnight", name: "نیمه‌شب", night: ["#04060e", "#070b18", "#0a1022", "#0e162e", "#162244"], crimson: ["#a5b4fc", "#818cf8", "#6366f1", "#4f46e5", "#4338ca"], flame: ["#bae6fd", "#7dd3fc", "#38bdf8", "#0ea5e9"], ink: "#ffffff" },
];

const NIGHT = [950, 900, 850, 800, 700];
const CRIM = [300, 400, 500, 600, 700];
const FLAME = [300, 400, 500, 600];

export function applyTheme(id: string) {
  const t = THEMES.find((x) => x.id === id) ?? THEMES[0];
  const s = document.documentElement.style;
  NIGHT.forEach((n, i) => s.setProperty(`--color-night-${n}`, t.night[i]));
  CRIM.forEach((n, i) => s.setProperty(`--color-crimson-${n}`, t.crimson[i]));
  FLAME.forEach((n, i) => s.setProperty(`--color-flame-${n}`, t.flame[i]));
  s.setProperty("--color-on-accent", t.ink);
  document.documentElement.dataset.theme = t.id;
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", t.night[0]);
  try { localStorage.setItem("pp_theme", t.id); } catch { /* ignore */ }
}

export function currentTheme(): string {
  try { return localStorage.getItem("pp_theme") || "fire"; } catch { return "fire"; }
}
