import type { Download, Movie, MovieType } from "../data/movies";

const BASE: string = ((import.meta as any).env?.VITE_API_BASE ?? "").replace(/\/+$/, "");
export const API_BASE = BASE;

const PALETTE: [string, string][] = [
  ["#3a1c04", "#c26a12"], ["#08202b", "#155e75"], ["#1c1503", "#a16207"],
  ["#240a2e", "#7e22ce"], ["#0b2a1c", "#15803d"], ["#2b0a0a", "#b91c1c"],
];
const hash = (s: string) => {
  let h = 0;
  for (const c of s) h = (h * 31 + c.charCodeAt(0)) | 0;
  return Math.abs(h);
};

export interface ApiItem {
  pid: string; type?: MovieType; title: string; poster: string;
  rating: string | number | null; year: string | number | null;
}

export function toMovie(i: ApiItem, type: MovieType = "movie"): Movie {
  const pid = String(i.pid ?? "");
  const rating = Number(i.rating) || 0;
  const img = i.poster ? String(i.poster).replace(/^http:\/\//i, "https://") : undefined;
  return {
    id: hash(pid), pid, title: String(i.title ?? "").trim(), originalTitle: "",
    type: i.type ?? type, year: Number(i.year) || 0, duration: "",
    rating, match: Math.round(rating * 10), genres: [], description: "",
    poster: img, backdrop: img,
    gradient: PALETTE[hash(pid) % PALETTE.length], age: "", quality: "",
    director: "", cast: [],
  };
}

/* ---------- شبکه: تایم‌اوت + کش کوتاه‌مدت ---------- */
function timed(ms: number, outer?: AbortSignal) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  if (outer) {
    if (outer.aborted) ctl.abort();
    else outer.addEventListener("abort", () => ctl.abort(), { once: true });
  }
  return { signal: ctl.signal, done: () => clearTimeout(t) };
}

const TTL = 5 * 60_000;
const cache = new Map<string, { t: number; v: unknown }>();

async function get<T>(path: string, signal?: AbortSignal, ttl = 0): Promise<T> {
  if (ttl) {
    const c = cache.get(path);
    if (c && Date.now() - c.t < ttl) return c.v as T;
  }
  const { signal: s, done } = timed(15000, signal);
  try {
    const r = await fetch(BASE + path, { signal: s });
    if (!r.ok) throw new Error(String(r.status));
    const v = (await r.json()) as T;
    if (ttl) cache.set(path, { t: Date.now(), v });
    return v;
  } finally {
    done();
  }
}

export interface Home {
  movies: ApiItem[]; series: ApiItem[]; topMovies: ApiItem[]; topSeries: ApiItem[];
  _diag?: unknown;
}

export async function fetchHome(): Promise<Home> {
  const { signal, done } = timed(20000);
  try {
    let r: Response;
    try {
      r = await fetch(BASE + "/api/home", { signal });
    } catch (e) {
      throw new Error("اتصال به ووکر ناموفق (آدرس غلط/CORS/ووکر خاموش/تایم‌اوت): " + String(e));
    }
    const t = await r.text();
    if (!r.ok) throw new Error("جواب ووکر HTTP " + r.status + " | " + t.slice(0, 150));
    try {
      return JSON.parse(t) as Home;
    } catch {
      throw new Error("جواب ووکر JSON نیست (احتمالاً کد جدید دیپلوی نشده): " + t.slice(0, 150));
    }
  } finally {
    done();
  }
}

export async function searchMovies(q: string, signal?: AbortSignal): Promise<Movie[]> {
  const d = await get<{ items?: ApiItem[] }>("/api/search?q=" + encodeURIComponent(q), signal, TTL);
  return (d.items ?? []).map((i) => toMovie(i));
}

export async function fetchDetails(pid: string, signal?: AbortSignal): Promise<Partial<Movie>> {
  const d = await get<any>("/api/movie?pid=" + encodeURIComponent(pid), signal, TTL);
  const downloads: Download[] = Array.isArray(d.downloads) ? d.downloads : [];
  const best = ["2160p", "1080p", "720p", "480p"].find((q) => downloads.some((x) => x.quality === q));

  // نکته: کلیدهای undefined ساخته نمی‌شوند تا هنگام merge مقدارهای قبلی (مثل type) پاک نشوند
  const out: Partial<Movie> = {
    description: d.plot || "",
    genres: String(d.genre || "").split(/[،,]/).map((s: string) => s.trim()).filter(Boolean),
    duration: d.runtime || "",
    quality: best?.toUpperCase() ?? "",
    downloads,
    detailed: true,
  };
  const rating = Number(d.imdbRating);
  if (rating) out.rating = rating;
  if (d.trailerUrl) out.trailerUrl = d.trailerUrl;
  if (d.hasSeasons || downloads.some((x) => x.season != null)) out.type = "series";
  return out;
}

export async function fetchGenre(slug: string): Promise<Movie[]> {
  const d = await get<{ items?: ApiItem[] }>("/api/category?genre=" + slug + "&type=movie&page=1", undefined, TTL);
  return (d.items ?? []).map((i) => toMovie(i, "movie"));
}

export async function fetchCategory(
  o: { genre?: string; type: MovieType; page: number },
  signal?: AbortSignal,
): Promise<{ items: Movie[]; totalPages: number }> {
  const q = new URLSearchParams({ page: String(o.page), type: o.type });
  if (o.genre) q.set("genre", o.genre);
  else q.set("cat", o.type === "series" ? "series" : "movies");
  const d = await get<{ items?: ApiItem[]; totalPages?: number }>("/api/category?" + q.toString(), signal, TTL);
  return { items: (d.items ?? []).map((i) => toMovie(i, o.type)), totalPages: d.totalPages ?? 1 };
}
