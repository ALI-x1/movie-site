export interface GenreDef { slug: string; name: string }

export const GENRES: GenreDef[] = [
  { slug: "action", name: "اکشن" }, { slug: "drama", name: "درام" }, { slug: "sci-fi", name: "علمی‌تخیلی" },
  { slug: "horror", name: "ترسناک" }, { slug: "comedy", name: "کمدی" }, { slug: "mystery", name: "معمایی" },
  { slug: "adventure", name: "ماجراجویی" }, { slug: "fantasy", name: "فانتزی" }, { slug: "crime", name: "جنایی" },
  { slug: "thriller", name: "هیجان‌انگیز" }, { slug: "romance", name: "عاشقانه" }, { slug: "animation", name: "انیمیشن" },
  { slug: "anime", name: "انیمه" }, { slug: "family", name: "خانوادگی" }, { slug: "war", name: "جنگی" },
  { slug: "history", name: "تاریخی" }, { slug: "biography", name: "زندگی‌نامه" }, { slug: "documentary", name: "مستند" },
  { slug: "musical", name: "موزیکال" }, { slug: "western", name: "وسترن" }, { slug: "sport", name: "ورزشی" },
  { slug: "medical", name: "پزشکی" },
];

const norm = (s: string) => s.replace(/[\u200c\s]/g, "");
const MAP: Record<string, string> = Object.fromEntries(GENRES.map((g) => [norm(g.name), g.slug]));
export const genreSlug = (name: string): string | null => MAP[norm(name)] ?? null;
