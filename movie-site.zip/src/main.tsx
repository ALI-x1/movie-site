import { CatalogProvider } from "./data/catalog";
import { applyTheme, currentTheme } from "./lib/themes";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

applyTheme(currentTheme());

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <CatalogProvider><App /></CatalogProvider>
  </StrictMode>
);
