import { AnimatePresence, motion } from "framer-motion";
import { ArrowUp, Bookmark, Check, Download, Flame, MonitorSmartphone, RefreshCw, SearchX, ShieldCheck, Sparkles, Tv, Zap } from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Curtain from "./components/Curtain";
import Footer from "./components/Footer";
import Genres from "./components/Genres";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import MovieCard from "./components/MovieCard";
import MovieModal from "./components/MovieModal";
import MovieRow from "./components/MovieRow";
import Navbar from "./components/Navbar";
import PlayerModal from "./components/PlayerModal";
import SectionHead from "./components/SectionHead";
import TopTen from "./components/TopTen";
import { type Movie } from "./data/movies";
import { useCatalog } from "./data/catalog";
import { fetchCategory, fetchDetails, searchMovies } from "./lib/api";
import { genreSlug } from "./lib/genres";
import { toFa } from "./lib/format";
import { EASE } from "./lib/motion";
import { cn } from "./utils/cn";

const FILTER_GENRES = [
  "همه", "اکشن", "درام", "علمی‌تخیلی", "فانتزی",
  "جنایی", "ماجراجویی", "معمایی", "ترسناک", "کمدی",
];

const FEATURES = [
  {
    icon: Zap,
    title: "پخش بی‌وقفهٔ 4K",
    desc: "با سرورهای پرسرعت اختصاصی، حتی با اینترنت ضعیف بدون قطعی تماشا کن.",
  },
  {
    icon: Download,
    title: "دانلود و تماشای آفلاین",
    desc: "قسمت‌های بعدی سریالت را دانلود کن و در سفر بدون اینترنت ببین.",
  },
  {
    icon: MonitorSmartphone,
    title: "همهٔ دستگاه‌ها",
    desc: "موبایل، تبلت، تلویزیون و لپ‌تاپ؛ تماشایت را از هر جا ادامه بده.",
  },
  {
    icon: ShieldCheck,
    title: "پروفایل کودک",
    desc: "فضای امن و کنترل‌شده با محتوای مناسب سن کودکان.",
  },
];

const load = (k: string): Movie[] => {
  try { return JSON.parse(localStorage.getItem(k) || "[]"); } catch { return []; }
};
const slim = (m: Movie): Movie => ({ ...m, downloads: undefined, detailed: false, detailError: false, description: (m.description || "").slice(0, 160) });

export default function App() {
  const [boot, setBoot] = useState(true);
  const [curtainOpen, setCurtainOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Movie | null>(null);
  const [playing, setPlaying] = useState<Movie | null>(null);
  const [saved, setSaved] = useState<Movie[]>(() => load("pp_saved"));
  const [recent, setRecent] = useState<Movie[]>(() => load("pp_recent"));
  const myList = useMemo(() => saved.map((m) => m.id), [saved]);
  const [genre, setGenre] = useState("همه");
  const { newReleases, seriesList, trending } = useCatalog();
  const [searchResults, setSearchResults] = useState<Movie[]>([]);
  const [kind, setKind] = useState<"movie" | "series">("movie");
  const [archive, setArchive] = useState<Movie[]>([]);
  const [archPage, setArchPage] = useState(1);
  const [archTotal, setArchTotal] = useState(1);
  const [archLoading, setArchLoading] = useState(true);
  const [archError, setArchError] = useState(false);
  const [archTick, setArchTick] = useState(0);
  const [sort, setSort] = useState<"new" | "rating" | "year">("new");
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState(false);
  const [detailTick, setDetailTick] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [showTop, setShowTop] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const savedRef = useRef(saved);
  savedRef.current = saved;
  const queryRef = useRef(query);
  queryRef.current = query;
  const sentinel = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      setBoot(false);
      return;
    }
    const a = setTimeout(() => setCurtainOpen(true), 1100);
    const b = setTimeout(() => setBoot(false), 2300);
    return () => { clearTimeout(a); clearTimeout(b); };
  }, []);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 900);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2200);
  }, []);

  // lock body scroll when overlays are open
  useEffect(() => {
    document.body.style.overflow = selected || playing ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [selected, playing]);

  const isSaved = useCallback((id: number) => myList.includes(id), [myList]);

  const toggleSave = useCallback((m: Movie) => {
    const had = savedRef.current.some((x) => x.id === m.id);
    setSaved((l) => (l.some((x) => x.id === m.id) ? l.filter((x) => x.id !== m.id) : [slim(m), ...l]));
    showToast(had ? "از لیست حذف شد" : "به لیست اضافه شد");
  }, [showToast]);

  useEffect(() => {
    try { localStorage.setItem("pp_saved", JSON.stringify(saved)); } catch { /* ignore */ }
  }, [saved]);
  useEffect(() => {
    try { localStorage.setItem("pp_recent", JSON.stringify(recent)); } catch { /* ignore */ }
  }, [recent]);
  useEffect(() => {
    if (!selected) return;
    setRecent((r) => [slim(selected), ...r.filter((x) => x.id !== selected.id)].slice(0, 12));
  }, [selected?.pid]);

  const openPlay = (m: Movie) => setPlaying(m);

  const searching = query.trim().length > 0;

  useEffect(() => {
    const q = query.trim();
    if (!q) { setSearchResults([]); setSearchLoading(false); setSearchError(false); return; }
    const ctl = new AbortController();
    setSearchLoading(true);
    setSearchError(false);
    const t = setTimeout(() => {
      searchMovies(q, ctl.signal)
        .then((r) => { setSearchResults(r); setSearchLoading(false); })
        .catch(() => {
          if (ctl.signal.aborted) return;
          setSearchResults([]); setSearchError(true); setSearchLoading(false);
        });
    }, 350);
    return () => { clearTimeout(t); ctl.abort(); };
  }, [query]);

  useEffect(() => {
    const slug = genre === "همه" ? null : genreSlug(genre);
    if (genre !== "همه" && !slug) { setArchive([]); setArchLoading(false); return; }
    const ctl = new AbortController();
    setArchLoading(true);
    setArchError(false);
    fetchCategory({ type: kind, page: archPage, ...(slug ? { genre: slug } : {}) }, ctl.signal)
      .then((r) => {
        setArchTotal(r.totalPages);
        setArchive((p) => (archPage === 1 ? r.items : [...p, ...r.items.filter((x) => !p.some((y) => y.id === x.id))]));
        setArchLoading(false);
      })
      .catch(() => {
        if (ctl.signal.aborted) return;
        setArchError(true);
        setArchLoading(false);
      });
    return () => ctl.abort();
  }, [kind, genre, archPage, archTick]);

  // اسکرول بی‌نهایت: وقتی ته آرشیو دیده شد، صفحه‌ی بعد را بگیر
  useEffect(() => {
    const el = sentinel.current;
    if (!el || archLoading || archError || archPage >= archTotal || !archive.length) return;
    const io = new IntersectionObserver(
      (es) => {
        if (es[0].isIntersecting) {
          io.disconnect();
          setArchPage((p) => p + 1);
        }
      },
      { rootMargin: "500px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [archLoading, archError, archPage, archTotal, archive.length]);

  // دکمه‌ی برگشت گوشی، مودال را می‌بندد (نه کل سایت را)
  const modalOpen = !!selected;
  useEffect(() => {
    if (!modalOpen) return;
    history.pushState({ modal: true }, "");
    const onPop = () => { setPlaying(null); setSelected(null); };
    window.addEventListener("popstate", onPop);
    return () => {
      window.removeEventListener("popstate", onPop);
      if (history.state?.modal) history.back();
    };
  }, [modalOpen]);


  useEffect(() => {
    if (!selected || selected.detailed) return;
    const pid = selected.pid;
    const ctl = new AbortController();
    fetchDetails(pid, ctl.signal)
      .then((d) => setSelected((cur) => (cur && cur.pid === pid ? { ...cur, ...d, rating: d.rating ?? cur.rating } : cur)))
      .catch(() => {
        if (ctl.signal.aborted) return;
        setSelected((cur) => (cur && cur.pid === pid ? { ...cur, detailed: true, detailError: true } : cur));
      });
    return () => ctl.abort();
  }, [selected?.pid, detailTick]);

  const retryDetails = () => {
    setSelected((cur) => (cur ? { ...cur, detailed: false, detailError: false } : cur));
    setDetailTick((t) => t + 1);
  };

  const pickGenre = (g: string) => { setGenre(g); setArchPage(1); setArchive([]); };
  const pickKind = (k: "movie" | "series") => { setKind(k); setArchPage(1); setArchive([]); };
  const sortedArchive = useMemo(() => {
    if (sort === "new") return archive;
    const key = sort === "rating" ? (m: Movie) => m.rating : (m: Movie) => m.year;
    return [...archive].sort((a, b) => key(b) - key(a));
  }, [archive, sort]);

  const myMovies = saved;

  const goTo = useCallback((id: string) => {
    const run = () => {
      if (id === "home") window.scrollTo({ top: 0, behavior: "smooth" });
      else document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    };
    if (queryRef.current.trim()) { setQuery(""); setTimeout(run, 120); }
    else run();
  }, []);

  const handleMyListClick = () => {
    if (myList.length) goTo("mylist");
    else showToast("لیست شما هنوز خالی است");
  };

  const gridCls = "grid grid-cols-2 gap-x-4 gap-y-7 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6";

  return (
    <div className="relative min-h-screen bg-night-950 text-white">
      {/* ambience */}
      <div className="ambience pointer-events-none fixed inset-0 z-0" />
      {/* cinematic grain */}
      <div className="grain pointer-events-none fixed inset-0 z-[90] hidden opacity-[0.05] lg:block" />

      {/* ورودی: پرده‌ی سینما */}
      {boot && <Curtain open={curtainOpen} />}

      <Navbar
        query={query}
        onQueryChange={setQuery}
        myListCount={myList.length}
        onMyListClick={handleMyListClick}
        onNavigate={goTo}
      />

      {searching ? (
        /* ---------- search results ---------- */
        <main className="relative z-10 mx-auto min-h-screen max-w-[1320px] px-4 pb-16 pt-28 lg:px-10 lg:pt-32">
          <div className="mb-8 flex items-center justify-between gap-4">
            <div>
              <h1 className="font-display text-4xl leading-tight md:text-5xl">نتایج جستجو</h1>
              <p className="mt-2 text-sm text-zinc-400">
                {searchLoading && !searchResults.length
                  ? "در حال جستجو…"
                  : searchResults.length
                    ? `${toFa(searchResults.length)} عنوان برای «${query}» پیدا شد`
                    : `چیزی برای «${query}» پیدا نشد`}
              </p>
            </div>
            <button onClick={() => setQuery("")} className="btn-ghost h-11 shrink-0 px-6 text-sm">
              بازگشت
            </button>
          </div>

          {searchResults.length ? (
            <div className={gridCls}>
              {searchResults.map((m) => (
                <MovieCard
                  key={m.id}
                  movie={m}
                  fluid
                  onOpen={setSelected}
                  saved={isSaved(m.id)}
                  onToggleSave={toggleSave}
                />
              ))}
            </div>
          ) : searchLoading ? (
            <div className={gridCls}>
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="aspect-[2/3] animate-pulse rounded-xl bg-white/5" />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center gap-4 py-24 text-center">
              <SearchX className="h-14 w-14 text-zinc-700" />
              <p className="font-display text-3xl text-zinc-300">{searchError ? "جستجو ناموفق بود" : "نتیجه‌ای یافت نشد"}</p>
              <p className="text-sm text-zinc-500">
                {searchError ? "اتصال را بررسی کن و دوباره امتحان کن" : "عنوان یا نام دیگری را امتحان کنید"}
              </p>
            </div>
          )}
        </main>
      ) : (
        /* ---------- home ---------- */
        <main className="relative z-10">
          <Hero
            onOpen={setSelected}
            onPlay={openPlay}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          <Marquee />

          <TopTen
            onOpen={setSelected}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          {recent.length > 0 && (
            <MovieRow
              id="recent"
              title="اخیراً دیدی"
              subtitle="از همان‌جا که بودی ادامه بده"
              movies={recent}
              onOpen={setSelected}
              onToggleSave={toggleSave}
              isSaved={isSaved}
            />
          )}
          <MovieRow
            id="trending"
            title="پرطرفدار این هفته"
            subtitle="آنچه بقیه این روزها تماشا می‌کنند"
            icon={Flame}
            movies={trending}
            onOpen={setSelected}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          {/* explore archive */}
          <section id="movies" className="py-14">
            <div className="mx-auto max-w-[1320px] px-4 lg:px-10">
              <SectionHead
                title="کاوش در آرشیو"
                subtitle={archLoading && !archive.length ? "در حال بارگذاری…" : `${toFa(archive.length)} عنوان، آمادهٔ تماشا`}
              />

              <div className="mb-5 flex flex-wrap items-center justify-between gap-x-6 gap-y-3">
                <div className="relative inline-flex rounded-full bg-white/[0.06] p-1 ring-1 ring-white/10">
                  {(["movie", "series"] as const).map((k) => (
                    <button
                      key={k}
                      onClick={() => pickKind(k)}
                      className={cn(
                        "relative isolate rounded-full px-6 py-2 text-sm font-bold transition-colors",
                        kind === k ? "text-on-accent" : "text-zinc-400 hover:text-white"
                      )}
                    >
                      {kind === k && (
                        <motion.span
                          layoutId="kind-pill"
                          className="absolute inset-0 -z-10 rounded-full bg-crimson-500"
                          transition={{ duration: 0.4, ease: EASE }}
                        />
                      )}
                      {k === "movie" ? "فیلم‌ها" : "سریال‌ها"}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-1 text-xs">
                  <span className="me-2 text-zinc-500">ترتیب</span>
                  {([["new", "جدیدترین"], ["rating", "امتیاز"], ["year", "سال ساخت"]] as const).map(([k, l]) => (
                    <button
                      key={k}
                      onClick={() => setSort(k)}
                      className={cn(
                        "rounded-full px-3.5 py-1.5 font-bold transition",
                        sort === k ? "bg-white/15 text-white" : "text-zinc-400 hover:text-white"
                      )}
                    >
                      {l}
                    </button>
                  ))}
                </div>
              </div>

              <div className="no-scrollbar mb-8 flex gap-2 overflow-x-auto pb-1">
                {FILTER_GENRES.map((g) => (
                  <button
                    key={g}
                    onClick={() => pickGenre(g)}
                    className={cn(
                      "shrink-0 rounded-full px-4 py-2 text-sm font-bold ring-1 transition-all duration-300",
                      genre === g
                        ? "bg-flame-500 text-night-950 ring-transparent"
                        : "text-zinc-300 ring-white/15 hover:bg-white/10 hover:text-white"
                    )}
                  >
                    {g}
                  </button>
                ))}
              </div>

              <div className={gridCls}>
                {sortedArchive.map((m) => (
                  <MovieCard
                    key={m.id}
                    movie={m}
                    fluid
                    onOpen={setSelected}
                    saved={isSaved(m.id)}
                    onToggleSave={toggleSave}
                  />
                ))}
              </div>

              {archLoading && archive.length === 0 && (
                <div className={gridCls}>
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="aspect-[2/3] animate-pulse rounded-xl bg-white/5" />
                  ))}
                </div>
              )}
              {archError && (
                <div className="flex flex-col items-center gap-3 py-12 text-center">
                  <p className="text-sm text-zinc-400">دریافت لیست ناموفق بود.</p>
                  <button onClick={() => setArchTick((t) => t + 1)} className="btn-ghost h-11 px-6 text-sm">
                    <RefreshCw className="h-4 w-4" />
                    تلاش دوباره
                  </button>
                </div>
              )}
              {!archLoading && !archError && archive.length === 0 && (
                <p className="py-16 text-center text-sm text-zinc-500">موردی برای نمایش پیدا نشد.</p>
              )}
              {archPage < archTotal && archive.length > 0 && !archError && (
                <div ref={sentinel} className="mt-10 flex justify-center">
                  <button
                    onClick={() => setArchPage((p) => p + 1)}
                    disabled={archLoading}
                    className="btn-ghost h-12 px-9 text-sm disabled:opacity-50"
                  >
                    {archLoading ? "در حال بارگذاری…" : "نمایش بیشتر"}
                  </button>
                </div>
              )}
            </div>
          </section>

          <Genres onPick={(g) => { pickGenre(g); document.getElementById("movies")?.scrollIntoView({ behavior: "smooth" }); }} />

          <MovieRow
            id="series"
            title="سریال‌های برگزیده"
            subtitle="قسمت‌های جدید، هر هفته"
            icon={Tv}
            movies={seriesList}
            onOpen={setSelected}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          <MovieRow
            id="new"
            title={`تازه‌های ${toFa(2026)}`}
            subtitle="تازه‌ترین اکران‌های پرده‌پلاس"
            icon={Sparkles}
            movies={newReleases}
            onOpen={setSelected}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          {myMovies.length > 0 && (
            <MovieRow
              id="mylist"
              title="لیست من"
              subtitle="ذخیره‌شده برای تماشای بعدی"
              icon={Bookmark}
              movies={myMovies}
              onOpen={setSelected}
              onToggleSave={toggleSave}
              isSaved={isSaved}
            />
          )}

          {/* features */}
          <section className="py-16">
            <div className="mx-auto max-w-[1320px] px-4 lg:px-10">
              <SectionHead title="چرا پرده‌پلاس؟" subtitle="چهار چیزی که تماشا را راحت‌تر می‌کند" />
              <div className="grid gap-x-0 gap-y-10 sm:grid-cols-2 lg:grid-cols-4 lg:divide-x lg:divide-white/10">
                {FEATURES.map((f) => (
                  <div key={f.title} className="lg:px-8 lg:first:ps-0 lg:last:pe-0">
                    <f.icon className="mb-4 h-8 w-8 text-flame-400" strokeWidth={1.6} />
                    <h3 className="mb-2 text-lg font-extrabold">{f.title}</h3>
                    <p className="text-sm leading-7 text-zinc-400">{f.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </main>
      )}

      <Footer />

      {/* overlays */}
      <AnimatePresence>
        {selected && (
          <MovieModal
            key={selected.id}
            movie={selected}
            onClose={() => setSelected(null)}
            onPlay={openPlay}
            onToggleSave={toggleSave}
            isSaved={isSaved}
            onSelect={setSelected}
            onRetry={retryDetails}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {playing && (
          <PlayerModal movie={playing} onClose={() => setPlaying(null)} />
        )}
      </AnimatePresence>

      {/* دکمه‌ی برگشت به بالا */}
      <AnimatePresence>
        {showTop && !selected && !playing && !searching && (
          <motion.button
            key="top"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            aria-label="برگشت به بالا"
            className="btn-accent fixed bottom-24 start-4 z-40 h-12 w-12 lg:bottom-6"
            style={{ marginBottom: "env(safe-area-inset-bottom)" }}
          >
            <ArrowUp className="h-5 w-5" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* پیام کوتاه */}
      <AnimatePresence>
        {toast && (
          <motion.div
            key="toast"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 12 }}
            transition={{ duration: 0.3, ease: EASE }}
            className="pointer-events-none fixed inset-x-0 bottom-24 z-[95] flex justify-center px-4 lg:bottom-8"
            style={{ marginBottom: "env(safe-area-inset-bottom)" }}
          >
            <span className="flex items-center gap-2 rounded-full border border-white/10 bg-night-800/95 px-5 py-3 text-sm font-bold shadow-2xl backdrop-blur-xl">
              <Check className="h-4 w-4 text-flame-400" />
              {toast}
            </span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
