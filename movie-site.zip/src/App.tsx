import { AnimatePresence, motion } from "framer-motion";
import { Bookmark, Clapperboard, Download, Flame, MonitorSmartphone, SearchX, ShieldCheck, Sparkles, Tv, Zap } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import Footer from "./components/Footer";
import Genres from "./components/Genres";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import MovieCard from "./components/MovieCard";
import MovieModal from "./components/MovieModal";
import MovieRow from "./components/MovieRow";
import Navbar from "./components/Navbar";
import PlayerModal from "./components/PlayerModal";
import TopTen from "./components/TopTen";
import { type Movie } from "./data/movies";
import { useCatalog } from "./data/catalog";
import { fetchCategory, fetchDetails, searchMovies } from "./lib/api";
import { genreSlug } from "./lib/genres";
import { toFa } from "./lib/format";
import { EASE } from "./lib/motion";
import { cn } from "./utils/cn";

const FILTER_GENRES = [
  "همه", "اکشن", "درام", "علمی‌تخیلی", "فانتزی",
  "جنایی", "ماجراجویی", "معمایی", "ترسناک", "کمدی",
];

const FEATURES = [
  {
    icon: Zap,
    title: "پخش بی‌وقفهٔ 4K",
    desc: "با سرورهای پرسرعت اختصاصی، حتی با اینترنت ضعیف بدون قطعی تماشا کن.",
    tint: "from-flame-500 to-crimson-500",
  },
  {
    icon: Download,
    title: "دانلود و تماشای آفلاین",
    desc: "قسمت‌های بعدی سریالت را دانلود کن و در سفر بدون اینترنت ببین.",
    tint: "from-sky-500 to-cyan-400",
  },
  {
    icon: MonitorSmartphone,
    title: "همهٔ دستگاه‌ها",
    desc: "موبایل، تبلت، تلویزیون و لپ‌تاپ؛ تماشایت را از هر جا ادامه بده.",
    tint: "from-violet-500 to-fuchsia-500",
  },
  {
    icon: ShieldCheck,
    title: "پروفایل کودک",
    desc: "فضای امن و کنترل‌شده با محتوای مناسب سن کودکان.",
    tint: "from-emerald-500 to-teal-400",
  },
];

const load = (k: string): Movie[] => {
  try { return JSON.parse(localStorage.getItem(k) || "[]"); } catch { return []; }
};
const slim = (m: Movie): Movie => ({ ...m, downloads: undefined, detailed: false, detailError: false, description: (m.description || "").slice(0, 160) });

export default function App() {
  const [boot, setBoot] = useState(true);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Movie | null>(null);
  const [playing, setPlaying] = useState<Movie | null>(null);
  const [saved, setSaved] = useState<Movie[]>(() => load("pp_saved"));
  const [recent, setRecent] = useState<Movie[]>(() => load("pp_recent"));
  const myList = useMemo(() => saved.map((m) => m.id), [saved]);
  const [genre, setGenre] = useState("همه");
  const { movies, newReleases, seriesList, trending } = useCatalog();
  const [searchResults, setSearchResults] = useState<Movie[]>([]);
  const [kind, setKind] = useState<"movie" | "series">("movie");
  const [archive, setArchive] = useState<Movie[]>([]);
  const [archPage, setArchPage] = useState(1);
  const [archTotal, setArchTotal] = useState(1);
  const [archLoading, setArchLoading] = useState(true);
  const [sort, setSort] = useState<"new" | "rating" | "year">("new");

  useEffect(() => {
    const t = setTimeout(() => setBoot(false), 1700);
    return () => clearTimeout(t);
  }, []);

  // lock body scroll when overlays are open
  useEffect(() => {
    document.body.style.overflow = selected || playing ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [selected, playing]);

  const isSaved = useCallback((id: number) => myList.includes(id), [myList]);

  const toggleSave = useCallback((m: Movie) => {
    setSaved((l) => (l.some((x) => x.id === m.id) ? l.filter((x) => x.id !== m.id) : [slim(m), ...l]));
  }, []);

  useEffect(() => {
    try { localStorage.setItem("pp_saved", JSON.stringify(saved)); } catch { /* ignore */ }
  }, [saved]);
  useEffect(() => {
    try { localStorage.setItem("pp_recent", JSON.stringify(recent)); } catch { /* ignore */ }
  }, [recent]);
  useEffect(() => {
    if (!selected) return;
    setRecent((r) => [slim(selected), ...r.filter((x) => x.id !== selected.id)].slice(0, 12));
  }, [selected?.pid]);

  const openPlay = (m: Movie) => {
    setSelected(null);
    setPlaying(m);
  };

  const searching = query.trim().length > 0;

  useEffect(() => {
    const q = query.trim();
    if (!q) { setSearchResults([]); return; }
    let live = true;
    const t = setTimeout(() => {
      searchMovies(q).then((r) => live && setSearchResults(r)).catch(() => live && setSearchResults([]));
    }, 350);
    return () => { live = false; clearTimeout(t); };
  }, [query]);

  useEffect(() => {
    const slug = genre === "همه" ? null : genreSlug(genre);
    if (genre !== "همه" && !slug) { setArchive([]); setArchLoading(false); return; }
    let live = true;
    setArchLoading(true);
    fetchCategory({ type: kind, page: archPage, ...(slug ? { genre: slug } : {}) })
      .then((r) => {
        if (!live) return;
        setArchTotal(r.totalPages);
        setArchive((p) => (archPage === 1 ? r.items : [...p, ...r.items.filter((x) => !p.some((y) => y.id === x.id))]));
      })
      .catch(() => {})
      .finally(() => live && setArchLoading(false));
    return () => { live = false; };
  }, [kind, genre, archPage]);

  // دکمه‌ی برگشت گوشی، مودال را می‌بندد (نه کل سایت را)
  const modalOpen = !!selected;
  useEffect(() => {
    if (!modalOpen) return;
    history.pushState({ modal: true }, "");
    const onPop = () => setSelected(null);
    window.addEventListener("popstate", onPop);
    return () => {
      window.removeEventListener("popstate", onPop);
      if (history.state?.modal) history.back();
    };
  }, [modalOpen]);


  useEffect(() => {
    if (!selected || selected.detailed) return;
    const pid = selected.pid;
    fetchDetails(pid)
      .then((d) => setSelected((cur) => (cur && cur.pid === pid ? { ...cur, ...d, rating: d.rating ?? cur.rating } : cur)))
      .catch(() => setSelected((cur) => (cur && cur.pid === pid ? { ...cur, detailed: true, detailError: true } : cur)));
  }, [selected?.pid]);

  const pickGenre = (g: string) => { setGenre(g); setArchPage(1); setArchive([]); };
  const pickKind = (k: "movie" | "series") => { setKind(k); setArchPage(1); setArchive([]); };
  const sortedArchive = useMemo(() => {
    if (sort === "new") return archive;
    const key = sort === "rating" ? (m: Movie) => m.rating : (m: Movie) => m.year;
    return [...archive].sort((a, b) => key(b) - key(a));
  }, [archive, sort]);

  const myMovies = saved;

  const handleMyListClick = () => {
    const id = myList.length ? "mylist" : "home";
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="relative min-h-screen bg-night-950 text-white">
      {/* ambience */}
      <div className="pointer-events-none fixed inset-0 z-0 bg-[radial-gradient(70%_50%_at_50%_0%,rgba(255,59,78,0.08),transparent)]" />
      {/* cinematic grain */}
      <div className="grain pointer-events-none fixed inset-0 z-[90] opacity-[0.05]" />

      {/* preloader */}
      <AnimatePresence>
        {boot && (
          <motion.div
            key="boot"
            exit={{ opacity: 0, scale: 1.06 }}
            transition={{ duration: 0.6, ease: EASE }}
            className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-6 bg-night-950"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0, rotate: -8 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200, damping: 16 }}
              className="glow-primary grid h-20 w-20 place-items-center rounded-[1.6rem] bg-gradient-to-br from-crimson-500 to-flame-500"
            >
              <Clapperboard className="h-10 w-10 text-white" />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25, duration: 0.6, ease: EASE }}
              className="text-center"
            >
              <p className="text-2xl font-black">
                پرده
                <span className="bg-gradient-to-l from-crimson-400 to-flame-400 bg-clip-text text-transparent">
                  ‌پلاس
                </span>
              </p>
              <p className="mt-1.5 text-xs text-zinc-500">
                دنیای فیلم و سریال، بدون مرز
              </p>
            </motion.div>
            <div className="h-1 w-44 overflow-hidden rounded-full bg-white/10">
              <motion.div
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 1.15, ease: EASE, delay: 0.2 }}
                className="h-full rounded-full bg-gradient-to-l from-crimson-500 to-flame-500"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Navbar
        query={query}
        onQueryChange={setQuery}
        myListCount={myList.length}
        onMyListClick={handleMyListClick}
      />

      {searching ? (
        /* ---------- search results ---------- */
        <main className="relative z-10 mx-auto min-h-screen max-w-[1440px] px-4 pb-16 pt-28 lg:px-10">
          <div className="mb-8 flex items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-black md:text-3xl">نتایج جستجو</h1>
              <p className="mt-2 text-sm text-zinc-400">
                {searchResults.length
                  ? `${toFa(searchResults.length)} عنوان برای «${query}» پیدا شد`
                  : `چیزی برای «${query}» پیدا نشد`}
              </p>
            </div>
            <button
              onClick={() => setQuery("")}
              className="shrink-0 rounded-full bg-white/5 px-5 py-2.5 text-sm font-bold ring-1 ring-white/10 transition hover:bg-white/10"
            >
              بازگشت
            </button>
          </div>

          {searchResults.length ? (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
              {searchResults.map((m) => (
                <MovieCard
                  key={m.id}
                  movie={m}
                  fluid
                  onOpen={setSelected}
                  saved={isSaved(m.id)}
                  onToggleSave={toggleSave}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center gap-4 py-24 text-center">
              <SearchX className="h-14 w-14 text-zinc-700" />
              <p className="text-lg font-bold text-zinc-400">نتیجه‌ای یافت نشد</p>
              <p className="text-sm text-zinc-600">
                عنوان، ژانر یا نام کارگردان دیگری را امتحان کنید
              </p>
            </div>
          )}
        </main>
      ) : (
        /* ---------- home ---------- */
        <main className="relative z-10">
          <Hero
            onOpen={setSelected}
            onPlay={openPlay}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          <Marquee />

          <TopTen
            onOpen={setSelected}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          {recent.length > 0 && (
            <MovieRow
              id="recent"
              title="اخیراً دیدی"
              subtitle="از همان‌جا که بودی ادامه بده"
              movies={recent}
              onOpen={setSelected}
              onToggleSave={toggleSave}
              isSaved={isSaved}
            />
          )}
          <MovieRow
            id="trending"
            title="پرطرفدار این هفته"
            subtitle="آنچه بقیه این روزها تماشا می‌کنند"
            icon={Flame}
            movies={trending}
            onOpen={setSelected}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          {/* explore archive */}
          <section id="movies" className="py-14">
            <div className="mx-auto max-w-[1440px] px-4 lg:px-10">
              <div className="mb-6 flex items-center gap-3">
                <span className="h-9 w-1.5 rounded-full bg-gradient-to-b from-crimson-500 to-flame-500" />
                <div>
                  <h2 className="text-xl font-extrabold md:text-2xl">
                    کاوش در آرشیو
                  </h2>
                  <p className="mt-1 text-xs text-zinc-500 md:text-sm">
                    {archLoading && !archive.length ? "در حال بارگذاری…" : `${toFa(archive.length)} عنوان، آمادهٔ تماشا`}
                  </p>
                </div>
              </div>

              <div className="mb-4 inline-flex rounded-full bg-white/5 p-1 ring-1 ring-white/10">
                {(["movie", "series"] as const).map((k) => (
                  <button
                    key={k}
                    onClick={() => pickKind(k)}
                    className={cn(
                      "rounded-full px-5 py-2 text-sm font-bold transition",
                      kind === k ? "bg-gradient-to-l from-crimson-600 to-flame-500 text-white" : "text-zinc-400 hover:text-white"
                    )}
                  >
                    {k === "movie" ? "فیلم‌ها" : "سریال‌ها"}
                  </button>
                ))}
              </div>

              <div className="mb-4 flex flex-wrap items-center gap-2">
                <span className="text-xs text-zinc-500">ترتیب:</span>
                {([["new", "جدیدترین"], ["rating", "امتیاز"], ["year", "سال ساخت"]] as const).map(([k, l]) => (
                  <button
                    key={k}
                    onClick={() => setSort(k)}
                    className={cn(
                      "rounded-full px-3.5 py-1.5 text-xs font-bold ring-1 transition",
                      sort === k ? "bg-white/15 text-white ring-white/30" : "text-zinc-400 ring-white/10 hover:text-white"
                    )}
                  >
                    {l}
                  </button>
                ))}
              </div>

              <div className="no-scrollbar mb-8 flex gap-2 overflow-x-auto pb-1">
                {FILTER_GENRES.map((g) => (
                  <button
                    key={g}
                    onClick={() => pickGenre(g)}
                    className={cn(
                      "shrink-0 rounded-full px-4.5 py-2.5 text-sm font-bold ring-1 transition-all duration-300",
                      genre === g
                        ? "glow-primary bg-gradient-to-l from-crimson-600 to-flame-500 text-white ring-transparent"
                        : "bg-white/5 text-zinc-300 ring-white/10 hover:bg-white/10 hover:text-white"
                    )}
                  >
                    {g}
                  </button>
                ))}
              </div>

              <motion.div
                layout
                className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6"
              >
                <AnimatePresence mode="popLayout">
                  {sortedArchive.map((m) => (
                    <MovieCard
                      key={m.id}
                      movie={m}
                      fluid
                      onOpen={setSelected}
                      saved={isSaved(m.id)}
                      onToggleSave={toggleSave}
                    />
                  ))}
                </AnimatePresence>
              </motion.div>

              {archLoading && archive.length === 0 && (
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="aspect-[2/3] animate-pulse rounded-2xl bg-white/5" />
                  ))}
                </div>
              )}
              {!archLoading && archive.length === 0 && (
                <p className="py-16 text-center text-sm text-zinc-500">موردی برای نمایش پیدا نشد.</p>
              )}
              {archPage < archTotal && archive.length > 0 && (
                <div className="mt-8 flex justify-center">
                  <button
                    onClick={() => setArchPage((p) => p + 1)}
                    disabled={archLoading}
                    className="rounded-full bg-white/5 px-8 py-3 text-sm font-bold ring-1 ring-white/15 transition hover:bg-white/10 disabled:opacity-50"
                  >
                    {archLoading ? "در حال بارگذاری…" : "نمایش بیشتر"}
                  </button>
                </div>
              )}
            </div>
          </section>

          <Genres onPick={(g) => { pickGenre(g); document.getElementById("movies")?.scrollIntoView({ behavior: "smooth" }); }} />

          <MovieRow
            id="series"
            title="سریال‌های برگزیده"
            subtitle="قسمت‌های جدید، هر هفته"
            icon={Tv}
            movies={seriesList}
            onOpen={setSelected}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          <MovieRow
            id="new"
            title={`تازه‌های ${toFa(2026)}`}
            subtitle="تازه‌ترین اکران‌های پرده‌پلاس"
            icon={Sparkles}
            movies={newReleases}
            onOpen={setSelected}
            onToggleSave={toggleSave}
            isSaved={isSaved}
          />

          {myMovies.length > 0 && (
            <MovieRow
              id="mylist"
              title="لیست من"
              subtitle="ذخیره‌شده برای تماشای بعدی"
              icon={Bookmark}
              movies={myMovies}
              onOpen={setSelected}
              onToggleSave={toggleSave}
              isSaved={isSaved}
            />
          )}

          {/* features */}
          <section className="py-14">
            <div className="mx-auto max-w-[1440px] px-4 lg:px-10">
              <div className="mb-9 text-center">
                <p className="mb-3 text-sm font-bold text-crimson-400">
                  چرا پرده‌پلاس؟
                </p>
                <h2 className="text-3xl font-black md:text-4xl">
                  تجربه‌ای{" "}
                  <span className="bg-gradient-to-l from-crimson-400 to-flame-400 bg-clip-text text-transparent">
                    فراتر از تماشا
                  </span>
                </h2>
              </div>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {FEATURES.map((f, i) => (
                  <motion.div
                    key={f.title}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-40px" }}
                    transition={{ duration: 0.6, ease: EASE, delay: i * 0.08 }}
                    whileHover={{ y: -6 }}
                    className="rounded-3xl bg-white/[0.03] p-6 ring-1 ring-white/10 transition hover:bg-white/[0.06] hover:ring-white/20"
                  >
                    <span
                      className={cn(
                        "mb-4 inline-grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br",
                        f.tint
                      )}
                    >
                      <f.icon className="h-5 w-5 text-white" />
                    </span>
                    <h3 className="mb-2 font-extrabold">{f.title}</h3>
                    <p className="text-sm leading-7 text-zinc-400">{f.desc}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>
      )}

      <Footer />

      {/* overlays */}
      <AnimatePresence>
        {selected && (
          <MovieModal
            key={selected.id}
            movie={selected}
            onClose={() => setSelected(null)}
            onPlay={openPlay}
            onToggleSave={toggleSave}
            isSaved={isSaved}
            onSelect={setSelected}
          />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {playing && (
          <PlayerModal movie={playing} onClose={() => setPlaying(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}
