import { AnimatePresence, motion } from "framer-motion";
import { BookmarkCheck, BookmarkPlus, Calendar, Info, RefreshCw, Star, WifiOff } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useCatalog } from "../data/catalog";
import { typeLabel, type Movie } from "../data/movies";
import { faRating, toFa } from "../lib/format";
import { EASE } from "../lib/motion";
import { cn } from "../utils/cn";
import Poster from "./Poster";

interface Props {
  onOpen: (m: Movie) => void;
  onPlay?: (m: Movie) => void;
  onToggleSave: (m: Movie) => void;
  isSaved: (id: number) => boolean;
}

export default function Hero({ onOpen, onToggleSave, isSaved }: Props) {
  const { heroSlides, loading, reload } = useCatalog();
  const [index, setIndex] = useState(0);
  const scroller = useRef<HTMLDivElement>(null);
  const cards = useRef<(HTMLButtonElement | null)[]>([]);
  const paused = useRef(false);
  const resume = useRef<ReturnType<typeof setTimeout>>(undefined);
  const slide = heroSlides[index] ?? heroSlides[0];

  const go = (i: number) => {
    const sc = scroller.current;
    const el = cards.current[i];
    if (!sc || !el) return;
    const sr = sc.getBoundingClientRect();
    const er = el.getBoundingClientRect();
    sc.scrollBy({ left: er.left + er.width / 2 - (sr.left + sr.width / 2), behavior: "smooth" });
  };

  // کارت وسط = کارت فعال
  useEffect(() => {
    const sc = scroller.current;
    if (!sc || !heroSlides.length) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting && e.intersectionRatio >= 0.6) {
            const i = cards.current.indexOf(e.target as HTMLButtonElement);
            if (i >= 0) setIndex(i);
          }
        });
      },
      { root: sc, threshold: [0.6, 0.9] }
    );
    cards.current.forEach((c) => c && io.observe(c));
    return () => io.disconnect();
  }, [heroSlides.length]);

  // چرخش خودکار (با لمس/هاور کاربر یا مخفی بودن تب متوقف می‌شود)
  useEffect(() => {
    if (heroSlides.length < 2) return;
    const t = setInterval(() => {
      if (!paused.current && !document.hidden) go((index + 1) % heroSlides.length);
    }, 6500);
    return () => clearInterval(t);
  }, [index, heroSlides.length]);

  useEffect(() => () => clearTimeout(resume.current), []);

  if (!slide) {
    if (loading) return <section id="home" className="h-[70svh] animate-pulse bg-white/[0.03]" />;
    return (
      <section id="home" className="grid min-h-[70svh] place-items-center px-6 pt-24 text-center">
        <div className="max-w-sm space-y-4">
          <WifiOff className="mx-auto h-12 w-12 text-zinc-600" />
          <p className="text-lg font-extrabold">اتصال برقرار نشد</p>
          <p className="text-sm leading-7 text-zinc-500">لیست فیلم‌ها دریافت نشد. اینترنت را بررسی کن و دوباره امتحان کن.</p>
          <button
            onClick={reload}
            className="glow-primary mx-auto flex items-center gap-2 rounded-full bg-gradient-to-l from-crimson-600 to-flame-500 px-7 py-3 text-sm font-extrabold transition active:scale-95"
          >
            <RefreshCw className="h-4 w-4" />
            تلاش دوباره
          </button>
        </div>
      </section>
    );
  }
  const saved = isSaved(slide.id);

  return (
    <section id="home" className="relative overflow-hidden pb-10 pt-24 sm:pt-28">
      {/* پس‌زمینه: رنگ پوستر فعال، خیلی ملایم */}
      <AnimatePresence>
        <motion.div
          key={slide.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.1, ease: EASE }}
          className="absolute inset-0 overflow-hidden"
        >
          <Poster movie={slide} className="scale-110 opacity-30 blur-2xl" />
        </motion.div>
      </AnimatePresence>
      <div className="absolute left-1/2 top-10 h-72 w-72 -translate-x-1/2 rounded-full bg-crimson-500/20 blur-3xl" />
      <div className="absolute inset-0 bg-gradient-to-b from-night-950/30 via-night-950/60 to-night-950" />

      {/* چرخ‌فلک پوسترها */}
      <div
        ref={scroller}
        onPointerDown={() => {
          paused.current = true;
          clearTimeout(resume.current);
        }}
        onPointerUp={() => {
          clearTimeout(resume.current);
          resume.current = setTimeout(() => (paused.current = false), 4000);
        }}
        onMouseEnter={() => (paused.current = true)}
        onMouseLeave={() => (paused.current = false)}
        className="no-scrollbar relative z-10 flex snap-x snap-mandatory items-center gap-4 overflow-x-auto py-4 [--hw:min(58vw,250px)] sm:[--hw:230px] lg:[--hw:270px]"
        style={{ paddingInline: "calc(50% - var(--hw) / 2)" }}
      >
        {heroSlides.map((m, i) => (
          <button
            key={m.id}
            ref={(el) => { cards.current[i] = el; }}
            onClick={() => (i === index ? onOpen(m) : go(i))}
            aria-label={m.title}
            className={cn(
              "relative aspect-[2/3] w-[var(--hw)] shrink-0 snap-center overflow-hidden rounded-3xl bg-night-800 shadow-[0_30px_60px_-20px_rgba(0,0,0,0.9)] ring-1 ring-white/15 transition-all duration-500",
              i === index ? "scale-100 opacity-100" : "scale-[0.86] opacity-50"
            )}
          >
            <Poster movie={m} />
            <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-black/70 to-transparent" />
            {m.rating > 0 && (
              <span className="absolute start-2.5 top-2.5 flex items-center gap-1 rounded-full bg-black/60 px-2 py-1 text-[11px] font-bold backdrop-blur-md">
                <Star className="h-3 w-3 fill-flame-400 text-flame-400" />
                {faRating(m.rating)}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* اطلاعات عنوان فعال */}
      <div className="relative z-10 mx-auto mt-3 max-w-xl px-6 text-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={slide.id}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.4, ease: EASE }}
          >
            <div className="mb-3 flex items-center justify-center gap-3 text-xs text-zinc-300">
              <span className="rounded-full bg-crimson-500/90 px-3 py-1 text-[11px] font-bold">{typeLabel(slide)}</span>
              {slide.year > 0 && (
                <span className="flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 text-zinc-500" />
                  {toFa(slide.year)}
                </span>
              )}
              {slide.rating > 0 && (
                <span className="flex items-center gap-1.5 font-bold text-flame-400">
                  <Star className="h-3.5 w-3.5 fill-flame-400" />
                  {faRating(slide.rating)}
                </span>
              )}
            </div>
            <h1 className="line-clamp-2 text-2xl font-black leading-snug sm:text-4xl">{slide.title}</h1>
            <div className="mt-5 flex items-center justify-center gap-3">
              <button
                onClick={() => onOpen(slide)}
                className="glow-primary flex items-center gap-2 rounded-full bg-gradient-to-l from-crimson-600 via-crimson-500 to-flame-500 px-7 py-3.5 text-sm font-extrabold transition-transform duration-300 hover:scale-105 active:scale-95"
              >
                <Info className="h-4 w-4" />
                اطلاعات و دانلود
              </button>
              <button
                onClick={() => onToggleSave(slide)}
                aria-label={saved ? "حذف از لیست" : "ذخیره"}
                className={cn(
                  "grid h-12 w-12 place-items-center rounded-full ring-1 transition active:scale-95",
                  saved ? "bg-flame-500/15 text-flame-400 ring-flame-500/40" : "bg-white/5 ring-white/15 hover:bg-white/10"
                )}
              >
                {saved ? <BookmarkCheck className="h-5 w-5" /> : <BookmarkPlus className="h-5 w-5" />}
              </button>
            </div>
          </motion.div>
        </AnimatePresence>

        <div className="mt-6 flex items-center justify-center gap-2">
          {heroSlides.map((m, i) => (
            <button
              key={m.id}
              onClick={() => go(i)}
              aria-label={`اسلاید ${i + 1}`}
              className={cn(
                "h-1.5 rounded-full transition-all duration-500",
                i === index ? "w-7 bg-gradient-to-l from-crimson-500 to-flame-500" : "w-2 bg-white/25"
              )}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
