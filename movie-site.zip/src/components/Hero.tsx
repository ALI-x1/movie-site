import { AnimatePresence, motion } from "framer-motion";
import { BookmarkCheck, BookmarkPlus, Info, RefreshCw, Star, WifiOff } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useCatalog } from "../data/catalog";
import { typeLabel, type Movie } from "../data/movies";
import { faRating, toFa } from "../lib/format";
import { EASE } from "../lib/motion";
import { cn } from "../utils/cn";
import Poster from "./Poster";

interface Props {
  onOpen: (m: Movie) => void;
  onPlay?: (m: Movie) => void;
  onToggleSave: (m: Movie) => void;
  isSaved: (id: number) => boolean;
}

const DURATION = 7000;

export default function Hero({ onOpen, onToggleSave, isSaved }: Props) {
  const { heroSlides, loading, reload } = useCatalog();
  const [index, setIndex] = useState(0);
  const paused = useRef(false);
  const resume = useRef<ReturnType<typeof setTimeout>>(undefined);
  const elapsed = useRef(0);
  const bar = useRef<HTMLSpanElement>(null);
  const strip = useRef<HTMLDivElement>(null);
  const count = heroSlides.length;
  const slide = heroSlides[index] ?? heroSlides[0];

  const goTo = (i: number) => {
    if (!count) return;
    elapsed.current = 0;
    setIndex(((i % count) + count) % count);
  };

  // نوار پیشرفت اسلاید فعال
  useEffect(() => {
    elapsed.current = 0;
    if (bar.current) bar.current.style.transform = "scaleX(0)";
    // کوچک‌عکس فعال را وسط نوار فیلم بیاور
    const sc = strip.current;
    const el = sc?.children[index] as HTMLElement | undefined;
    if (sc && el) {
      const sr = sc.getBoundingClientRect();
      const er = el.getBoundingClientRect();
      sc.scrollBy({ left: er.left + er.width / 2 - (sr.left + sr.width / 2), behavior: "smooth" });
    }
  }, [index]);

  // چرخش خودکار (با هاور/لمس کاربر یا مخفی بودن تب متوقف می‌شود)
  useEffect(() => {
    if (count < 2) return;
    const t = setInterval(() => {
      if (paused.current || document.hidden) return;
      elapsed.current += 100;
      if (bar.current) bar.current.style.transform = `scaleX(${Math.min(1, elapsed.current / DURATION)})`;
      if (elapsed.current >= DURATION) {
        elapsed.current = 0;
        setIndex((i) => (i + 1) % count);
      }
    }, 100);
    return () => clearInterval(t);
  }, [count]);

  useEffect(() => () => clearTimeout(resume.current), []);

  if (!slide) {
    if (loading) return <section id="home" className="h-[70svh] animate-pulse bg-white/[0.03]" />;
    return (
      <section id="home" className="grid min-h-[70svh] place-items-center px-6 pt-24 text-center">
        <div className="max-w-sm space-y-4">
          <WifiOff className="mx-auto h-12 w-12 text-zinc-600" />
          <p className="font-display text-3xl">اتصال برقرار نشد</p>
          <p className="text-sm leading-7 text-zinc-400">لیست فیلم‌ها دریافت نشد. اینترنت را بررسی کن و دوباره امتحان کن.</p>
          <button onClick={reload} className="btn-accent mx-auto px-7 py-3 text-sm">
            <RefreshCw className="h-4 w-4" />
            تلاش دوباره
          </button>
        </div>
      </section>
    );
  }

  const saved = isSaved(slide.id);
  const ghostA = count > 1 ? heroSlides[(index + 1) % count] : null;
  const ghostB = count > 2 ? heroSlides[(index + 2) % count] : null;

  return (
    <section
      id="home"
      className="relative isolate overflow-hidden pb-8 pt-24 lg:pt-32"
      onMouseEnter={() => { paused.current = true; }}
      onMouseLeave={() => { paused.current = false; }}
      onPointerDown={() => {
        paused.current = true;
        clearTimeout(resume.current);
      }}
      onPointerUp={() => {
        clearTimeout(resume.current);
        resume.current = setTimeout(() => { paused.current = false; }, 5000);
      }}
    >
      {/* پس‌زمینه: پوستر فعال، بزرگ و محو */}
      <div className="absolute inset-0 -z-10">
        <AnimatePresence>
          <motion.div
            key={slide.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.2, ease: EASE }}
            className="absolute inset-0 overflow-hidden"
          >
            <div className="kenburns absolute inset-0">
              <Poster movie={slide} className="scale-125 opacity-50 blur-xl" />
            </div>
          </motion.div>
        </AnimatePresence>
        <div className="absolute inset-0 bg-gradient-to-t from-night-950 via-night-950/75 to-night-950/25" />
        <div className="absolute inset-0 bg-gradient-to-l from-night-950/80 via-night-950/30 to-transparent lg:from-night-950/90" />
      </div>

      <div className="mx-auto grid max-w-[1320px] items-center gap-10 px-5 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16 lg:px-10">
        {/* متن */}
        <div className="order-2 text-center lg:order-1 lg:text-start">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={slide.id}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.45, ease: EASE }}
            >
              <div className="mb-5 flex flex-wrap items-center justify-center gap-3 text-sm text-zinc-200 lg:justify-start">
                <span className="rounded-md bg-crimson-500 px-2.5 py-1 text-xs font-extrabold text-on-accent">{typeLabel(slide)}</span>
                {slide.year > 0 && <span className="font-semibold">{toFa(slide.year)}</span>}
                {slide.rating > 0 && (
                  <span className="flex items-center gap-1.5 font-bold text-flame-400">
                    <Star className="h-4 w-4 fill-flame-400" />
                    {faRating(slide.rating)}
                  </span>
                )}
              </div>
              <h1 className="font-display line-clamp-3 text-[clamp(2.6rem,7.2vw,6rem)] leading-[1.12] drop-shadow-[0_6px_30px_rgba(0,0,0,0.5)]">
                {slide.title}
              </h1>
              <div className="mt-8 flex items-center justify-center gap-3 lg:justify-start">
                <button onClick={() => onOpen(slide)} className="btn-accent h-12 px-7 text-sm">
                  <Info className="h-4 w-4" />
                  اطلاعات و دانلود
                </button>
                <button
                  onClick={() => onToggleSave(slide)}
                  aria-label={saved ? "حذف از لیست" : "ذخیره"}
                  className={cn(
                    "btn-ghost h-12 w-12",
                    saved && "!bg-flame-500/20 !text-flame-400 shadow-[inset_0_0_0_1px_color-mix(in_srgb,var(--color-flame-500)_50%,transparent)]"
                  )}
                >
                  {saved ? <BookmarkCheck className="h-5 w-5" /> : <BookmarkPlus className="h-5 w-5" />}
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* پوستر اصلی با دو پوستر پشتش */}
        <div className="order-1 flex justify-center lg:order-2">
          <div className="relative w-[min(60vw,280px)] lg:w-[340px]">
            {ghostB && (
              <div className="absolute inset-0 -translate-x-[34%] -rotate-[13deg] scale-90 overflow-hidden rounded-2xl bg-night-800 opacity-40 ring-1 ring-white/10">
                <Poster movie={ghostB} />
              </div>
            )}
            {ghostA && (
              <div className="absolute inset-0 -translate-x-[17%] -rotate-[6deg] scale-95 overflow-hidden rounded-2xl bg-night-800 opacity-70 ring-1 ring-white/10">
                <Poster movie={ghostA} />
              </div>
            )}
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={slide.id}
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.25}
                onDragEnd={(_, info) => {
                  if (info.offset.x < -60) goTo(index + 1);
                  else if (info.offset.x > 60) goTo(index - 1);
                }}
                initial={{ opacity: 0, y: 26, rotate: 2 }}
                animate={{ opacity: 1, y: 0, rotate: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.5, ease: EASE }}
                className="relative"
              >
                <button
                  onClick={() => onOpen(slide)}
                  aria-label={slide.title}
                  className="relative block aspect-[2/3] w-full overflow-hidden rounded-2xl bg-night-800 shadow-[0_40px_80px_-24px_rgba(0,0,0,0.95)] ring-1 ring-white/20"
                >
                  <Poster movie={slide} />
                </button>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* نوار فیلم: انتخاب اسلاید */}
      {count > 1 && (
        <div className="filmstrip mt-12 lg:mt-16">
          <div
            ref={strip}
            className="no-scrollbar relative mx-auto flex max-w-[1320px] gap-3 overflow-x-auto px-5 py-7 lg:justify-center lg:px-10"
          >
            {heroSlides.map((m, i) => (
              <button
                key={m.id}
                onClick={() => goTo(i)}
                aria-label={m.title}
                aria-current={i === index ? "true" : undefined}
                className={cn(
                  "relative aspect-[2/3] w-[54px] shrink-0 overflow-hidden rounded-md bg-night-800 transition-all duration-500 sm:w-[64px]",
                  i === index ? "scale-110 opacity-100 ring-2 ring-crimson-500" : "opacity-50 ring-1 ring-white/20 hover:opacity-90"
                )}
              >
                <Poster movie={m} />
                {i === index && (
                  <span className="absolute inset-x-0 bottom-0 h-1 bg-black/60">
                    <span
                      ref={bar}
                      className="block h-full origin-right bg-flame-400 transition-transform duration-100 ease-linear"
                      style={{ transform: "scaleX(0)" }}
                    />
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
