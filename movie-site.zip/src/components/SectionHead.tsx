import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";

interface Props {
  title: string;
  subtitle?: string;
  icon?: LucideIcon;
  children?: ReactNode;
}

/** عنوان یکسان همهٔ بخش‌ها: تیتر، توضیح کوتاه، خط جداکننده و (اختیاری) دکمه‌های کناری */
export default function SectionHead({ title, subtitle, icon: Icon, children }: Props) {
  return (
    <div className="mb-6 flex items-end gap-5">
      <div className="min-w-0">
        <h2 className="font-display flex items-center gap-2.5 text-[1.9rem] leading-tight md:text-[2.5rem]">
          {Icon && <Icon className="h-6 w-6 shrink-0 text-flame-400 md:h-7 md:w-7" />}
          {title}
        </h2>
        {subtitle && <p className="mt-1 text-sm text-zinc-400">{subtitle}</p>}
      </div>
      <span aria-hidden className="mb-3 hidden h-px flex-1 bg-white/10 sm:block" />
      {children}
    </div>
  );
}
