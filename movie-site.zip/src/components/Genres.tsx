import type { CSSProperties } from "react";
import { Compass, Drama, Fingerprint, Ghost, Laugh, Rocket, Sparkles, Swords, type LucideIcon } from "lucide-react";
import { toFa } from "../lib/format";
import { cn } from "../utils/cn";
import SectionHead from "./SectionHead";

interface Genre {
  name: string;
  icon: LucideIcon;
  color: string;
  count: number;
  wide: boolean;
}

const GENRES: Genre[] = [
  { name: "اکشن", icon: Swords, color: "#ef4444", count: 128, wide: true },
  { name: "درام", icon: Drama, color: "#8b5cf6", count: 214, wide: false },
  { name: "علمی‌تخیلی", icon: Rocket, color: "#06b6d4", count: 96, wide: false },
  { name: "ترسناک", icon: Ghost, color: "#94a3b8", count: 74, wide: false },
  { name: "کمدی", icon: Laugh, color: "#f59e0b", count: 153, wide: false },
  { name: "معمایی", icon: Fingerprint, color: "#2dd4bf", count: 88, wide: true },
  { name: "ماجراجویی", icon: Compass, color: "#60a5fa", count: 117, wide: true },
  { name: "فانتزی", icon: Sparkles, color: "#e879f9", count: 65, wide: true },
];

export default function Genres({ onPick }: { onPick?: (g: string) => void }) {
  return (
    <section id="genres" className="py-14">
      <div className="mx-auto max-w-[1320px] px-4 lg:px-10">
        <SectionHead title="کاوش بر اساس ژانر" subtitle="هر حال‌وهوایی که داشته باشی، یک دنیای تازه منتظرت است" />

        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
          {GENRES.map((g) => (
            <button
              key={g.name}
              onClick={() => onPick?.(g.name)}
              style={{ "--g": g.color } as CSSProperties}
              className={cn(
                "group relative flex h-32 flex-col justify-end overflow-hidden rounded-2xl border border-white/10 bg-night-850 p-5 text-start transition-all duration-500 hover:-translate-y-1 hover:border-[color:var(--g)] md:h-40",
                g.wide && "md:col-span-2"
              )}
            >
              <span
                aria-hidden
                className="absolute -bottom-16 -start-10 h-44 w-44 rounded-full opacity-25 blur-3xl transition-opacity duration-500 group-hover:opacity-60"
                style={{ background: g.color }}
              />
              <g.icon
                aria-hidden
                className="absolute -top-3 end-3 h-24 w-24 -rotate-12 transition-transform duration-500 group-hover:rotate-0 group-hover:scale-110 md:h-28 md:w-28"
                style={{ color: g.color, opacity: 0.35 }}
                strokeWidth={1.25}
              />
              <span className="relative">
                <span className="font-display block text-3xl leading-none md:text-4xl">{g.name}</span>
                <span className="mt-1.5 block text-xs text-zinc-400">{toFa(g.count)} عنوان</span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
