import {
  AtSign,
  Camera,
  Clapperboard,
  Heart,
  MonitorPlay,
  Send,
} from "lucide-react";
import { toFa } from "../lib/format";

const QUICK = [
  { label: "خانه", href: "#home" },
  { label: "فیلم‌ها", href: "#movies" },
  { label: "سریال‌ها", href: "#series" },
  { label: "برترین‌ها", href: "#top" },
  { label: "ژانرها", href: "#genres" },
];

const GENRE_LINKS = ["اکشن", "درام", "علمی‌تخیلی", "ترسناک", "کمدی", "مستند"];

const SOCIALS = [
  { icon: Camera, label: "اینستاگرام" },
  { icon: AtSign, label: "ایکس" },
  { icon: MonitorPlay, label: "یوتیوب" },
  { icon: Send, label: "تلگرام" },
];

export default function Footer() {
  return (
    <footer className="relative mt-20 overflow-hidden border-t border-white/10 bg-night-900 pb-24 lg:pb-0">
      <div className="mx-auto max-w-[1320px] px-4 pt-14 lg:px-10">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.4fr]">
          {/* brand */}
          <div>
            <div className="flex items-center gap-2.5">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-crimson-500 text-on-accent">
                <Clapperboard className="h-5 w-5" />
              </span>
              <span className="font-display text-3xl leading-none">پرده‌پلاس</span>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-7 text-zinc-400">
              خانهٔ سینمای تو؛ هزاران فیلم و سریال با کیفیت ۴K، دوبلهٔ اختصاصی و
              بدون وقفه، هرجا که باشی.
            </p>
            <div className="mt-5 flex gap-2.5">
              {SOCIALS.map((s) => (
                <button
                  key={s.label}
                  aria-label={s.label}
                  className="grid h-10 w-10 place-items-center rounded-full bg-white/[0.06] ring-1 ring-white/10 transition hover:-translate-y-1 hover:bg-crimson-500 hover:text-on-accent hover:ring-transparent"
                >
                  <s.icon className="h-4 w-4" />
                </button>
              ))}
            </div>
          </div>

          {/* quick links */}
          <div>
            <h4 className="font-display mb-4 text-xl text-white">دسترسی سریع</h4>
            <ul className="space-y-2.5 text-sm text-zinc-400">
              {QUICK.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="transition hover:text-flame-400">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* genres */}
          <div>
            <h4 className="font-display mb-4 text-xl text-white">ژانرها</h4>
            <ul className="space-y-2.5 text-sm text-zinc-400">
              {GENRE_LINKS.map((g) => (
                <li key={g}>
                  <a href="#genres" className="transition hover:text-flame-400">
                    {g}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* newsletter */}
          <div>
            <h4 className="font-display mb-4 text-xl text-white">از تازه‌ها باخبر شوید</h4>
            <p className="text-sm leading-7 text-zinc-400">
              هر هفته خلاصهٔ تازه‌ترین فیلم‌ها و سریال‌ها در صندوق ایمیل شما.
            </p>
            <form onSubmit={(e) => e.preventDefault()} className="mt-4 flex items-center gap-2">
              <input
                type="email"
                required
                placeholder="ایمیل شما"
                className="h-11 w-full rounded-full bg-white/[0.06] px-5 text-sm outline-none ring-1 ring-white/10 transition placeholder:text-zinc-500 focus:ring-crimson-500"
              />
              <button aria-label="عضویت" className="btn-accent h-11 w-12 shrink-0">
                <Send className="h-4 w-4 -scale-x-100" />
              </button>
            </form>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-zinc-500 sm:flex-row">
          <p>© {toFa(1405)} پرده‌پلاس — تمامی حقوق محتوا محفوظ است.</p>
          <p className="flex items-center gap-1.5">
            ساخته‌شده با
            <Heart className="h-3.5 w-3.5 fill-crimson-500 text-crimson-500" />
            برای عاشقان سینما
          </p>
        </div>
      </div>

      {/* نام سایت، بزرگ و نیمه‌پنهان در لبهٔ پایین */}
      <div
        aria-hidden
        className="font-display pointer-events-none mt-6 translate-y-[16%] select-none text-center text-[clamp(5rem,23vw,21rem)] leading-[0.85] text-transparent [-webkit-text-stroke:1.5px_rgba(255,255,255,0.1)]"
      >
        پرده‌پلاس
      </div>
    </footer>
  );
}
