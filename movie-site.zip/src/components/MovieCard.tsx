import { motion } from "framer-motion";
import { Bookmark, BookmarkCheck, Play, Star } from "lucide-react";
import { type Movie, typeLabel } from "../data/movies";
import { faRating, toFa } from "../lib/format";
import { cn } from "../utils/cn";
import Poster from "./Poster";

interface Props {
  movie: Movie;
  onOpen: (m: Movie) => void;
  saved?: boolean;
  onToggleSave?: (m: Movie) => void;
  fluid?: boolean;
  widthClass?: string;
  rank?: number;
}

export default function MovieCard({ movie, onOpen, saved, onToggleSave, fluid, widthClass, rank }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -6 }}
      whileTap={{ scale: 0.97 }}
      transition={{ type: "spring", stiffness: 320, damping: 26 }}
      className={cn(
        "group relative snap-start",
        fluid ? "w-full" : cn("shrink-0", widthClass ?? "w-[148px] sm:w-[172px] lg:w-[192px]")
      )}
    >
      <div className="relative">
        <div
          role="button"
          tabIndex={0}
          aria-label={movie.title}
          onClick={() => onOpen(movie)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              onOpen(movie);
            }
          }}
          className="relative aspect-[2/3] cursor-pointer overflow-hidden rounded-xl bg-night-800 ring-1 ring-white/10 transition-all duration-300 group-hover:ring-2 group-hover:ring-crimson-500 group-hover:shadow-[0_24px_50px_-16px_color-mix(in_srgb,var(--color-crimson-500)_55%,transparent)]"
        >
          <Poster movie={movie} className="transition-transform duration-700 group-hover:scale-105" />

          <div className="absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-black/70 to-transparent opacity-80 transition-opacity duration-300 group-hover:opacity-100" />

          {movie.badge && (
            <span className="absolute start-2 top-2 z-10 rounded-md bg-crimson-500 px-2 py-0.5 text-[10px] font-extrabold text-on-accent shadow-lg">
              {movie.badge}
            </span>
          )}

          {movie.rating > 0 && (
            <span className="absolute bottom-2 start-2 z-10 flex items-center gap-1 rounded-md bg-black/70 px-1.5 py-0.5 text-[11px] font-bold text-flame-400 backdrop-blur-sm">
              <Star className="h-3 w-3 fill-flame-400" />
              {faRating(movie.rating)}
            </span>
          )}

          {onToggleSave && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleSave(movie);
              }}
              aria-label={saved ? "حذف از لیست" : "افزودن به لیست"}
              className="absolute end-2 top-2 z-20 rounded-full bg-black/55 p-2 text-white ring-1 ring-white/20 backdrop-blur-md transition hover:scale-110 hover:bg-black/80 sm:opacity-0 sm:group-hover:opacity-100 sm:focus-visible:opacity-100"
            >
              {saved ? <BookmarkCheck className="h-4 w-4 text-flame-400" /> : <Bookmark className="h-4 w-4" />}
            </button>
          )}

          {/* دکمهٔ پخش هنگام هاور */}
          <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100">
            <span className="grid h-12 w-12 scale-75 place-items-center rounded-full bg-crimson-500 text-on-accent shadow-xl transition-transform duration-300 group-hover:scale-100">
              <Play className="h-5 w-5 fill-current" />
            </span>
          </div>
        </div>

        {rank != null && (
          <span
            aria-hidden
            className="font-display pointer-events-none absolute -bottom-4 -end-2 z-20 select-none text-[4.6rem] leading-none text-white [text-shadow:0_3px_0_var(--color-crimson-600),0_10px_26px_rgba(0,0,0,0.8)] sm:text-[5.6rem]"
          >
            {toFa(rank)}
          </span>
        )}
      </div>

      <div className={cn("px-0.5 pt-2.5", rank != null && "pe-14")}>
        <h3 className="line-clamp-1 text-[13px] font-bold text-zinc-100">{movie.title}</h3>
        <p className="mt-0.5 flex items-center gap-2 text-[11px] text-zinc-500">
          <span>{typeLabel(movie)}</span>
          {movie.year > 0 && <span>{toFa(movie.year)}</span>}
        </p>
      </div>
    </motion.div>
  );
}
