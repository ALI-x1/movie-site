import { motion } from "framer-motion";
import {
  Bookmark,
  BookmarkCheck,
  Calendar,
  Check,
  Clock,
  Copy,
  Download,
  Play,
  RefreshCw,
  Star,
  Tv,
  X,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { typeLabel, type Download as Dl, type Movie } from "../data/movies";
import { useCatalog } from "../data/catalog";
import { copyText } from "../lib/clipboard";
import { faRating, toFa } from "../lib/format";
import { EASE } from "../lib/motion";
import { cn } from "../utils/cn";
import Poster from "./Poster";
import VideoPlayer from "./VideoPlayer";

interface Props {
  movie: Movie;
  onClose: () => void;
  onPlay: (m: Movie) => void;
  onToggleSave: (m: Movie) => void;
  isSaved: (id: number) => boolean;
  onSelect: (m: Movie) => void;
  onRetry?: () => void;
}

const qRank = (q: string) => ["480p", "720p", "1080p", "2160p"].indexOf((q || "").toLowerCase());

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "shrink-0 rounded-full px-3.5 py-1.5 text-[12px] font-bold ring-1 transition",
        active
          ? "bg-flame-500 text-night-950 ring-transparent"
          : "bg-white/5 text-zinc-300 ring-white/10 hover:bg-white/10"
      )}
    >
      {children}
    </button>
  );
}

function Step({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <p className="mb-2 text-[11px] font-bold tracking-wide text-zinc-500">{label}</p>
      {children}
    </div>
  );
}

function Skeleton({ lines = 3 }: { lines?: number }) {
  return (
    <div className="space-y-2.5">
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className="h-3 animate-pulse rounded-full bg-white/10" style={{ width: `${95 - i * 12}%` }} />
      ))}
    </div>
  );
}

export default function MovieModal({ movie, onClose, onPlay, onToggleSave, isSaved, onSelect, onRetry }: Props) {
  const { movies } = useCatalog();
  const saved = isSaved(movie.id);
  const [kind, setKind] = useState<"dub" | "sub" | null>(null);
  const [quality, setQuality] = useState<string | null>(null);
  const [season, setSeason] = useState<number | null>(null);
  const [limit, setLimit] = useState(20);
  const [copied, setCopied] = useState<string | null>(null);
  const [playing, setPlaying] = useState<Dl | null>(null);

  useEffect(() => {
    setKind(null);
    setQuality(null);
    setSeason(null);
    setLimit(20);
  }, [movie.pid]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const dls = movie.downloads ?? [];
  const seasons = [...new Set(dls.map((d) => d.season).filter((s): s is number => typeof s === "number"))].sort((a, b) => a - b);
  const episodeCount = new Set(dls.filter((d) => d.episode != null).map((d) => `${d.season}-${d.episode}`)).size;
  const hasDub = dls.some((d) => d.isDubbed);
  const hasSub = dls.some((d) => !d.isDubbed);

  // انتخاب مرحله‌ای: نسخه ← کیفیت ← فصل ← فایل‌ها
  const activeKind: "dub" | "sub" = kind ?? (hasDub ? "dub" : "sub");
  const ofKind = dls.filter((d) => (activeKind === "dub") === d.isDubbed);
  const qualities = [...new Set(ofKind.map((d) => (d.quality || "").toLowerCase()))].filter(Boolean).sort((a, b) => qRank(b) - qRank(a));
  const activeQ = quality && qualities.includes(quality) ? quality : (qualities[0] ?? null);
  const ofQ = ofKind.filter((d) => !activeQ || (d.quality || "").toLowerCase() === activeQ);
  const seasonsQ = [...new Set(ofQ.map((d) => d.season).filter((s): s is number => typeof s === "number"))].sort((a, b) => a - b);
  const activeSeason = season !== null && seasonsQ.includes(season) ? season : (seasonsQ[0] ?? null);
  const files = ofQ
    .filter((d) => activeSeason === null || d.season === activeSeason)
    .filter((d, i, a) => a.findIndex((x) => x.link === d.link) === i)
    .sort((a, b) => (a.episode ?? 0) - (b.episode ?? 0));

  const byGenre = movies.filter((m) => m.id !== movie.id && m.genres.some((g) => movie.genres.includes(g)));
  const rest = movies.filter((m) => m.id !== movie.id && m.type === movie.type && !byGenre.includes(m));
  const similar = [...byGenre, ...rest].slice(0, 6);
  const headerImage = movie.backdrop ?? movie.poster;

  const copy = async (link: string) => {
    if (await copyText(link)) {
      setCopied(link);
      setTimeout(() => setCopied(null), 1500);
    } else {
      window.prompt("لینک را کپی کنید:", link);
    }
  };

  const copyAll = async () => {
    const text = files.map((f) => f.link).join("\n");
    if (await copyText(text)) {
      setCopied("__all");
      setTimeout(() => setCopied(null), 1500);
    } else {
      window.prompt("لینک‌ها را کپی کنید:", text);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center sm:p-4"
    >
      <div className="absolute inset-0 bg-night-950/80 backdrop-blur-md" onClick={onClose} />

      <motion.div
        role="dialog"
        aria-modal="true"
        aria-label={movie.title}
        initial={{ opacity: 0, y: 60, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 40, scale: 0.97 }}
        transition={{ duration: 0.45, ease: EASE }}
        className="relative flex max-h-[92dvh] w-full max-w-3xl flex-col overflow-hidden rounded-t-[28px] border border-white/10 bg-night-900 shadow-2xl sm:rounded-3xl"
      >
        {/* header */}
        <div className="relative h-60 shrink-0 overflow-hidden sm:h-72">
          <Poster movie={movie} src={headerImage} className="scale-125 object-top opacity-50 blur-2xl" />
          <div className="absolute inset-0 bg-gradient-to-t from-night-900 via-night-900/60 to-night-900/20" />
          {!movie.detailed && (
            <div className="absolute inset-x-0 bottom-0 h-0.5 overflow-hidden bg-white/10">
              <div className="loadbar h-full w-1/3 bg-gradient-to-l from-crimson-500 to-flame-500" />
            </div>
          )}
          <button
            onClick={onClose}
            aria-label="بستن"
            className="absolute end-4 top-4 z-10 rounded-full bg-black/50 p-2.5 ring-1 ring-white/20 backdrop-blur-md transition hover:scale-110 hover:bg-black/80"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="absolute inset-x-5 bottom-4 flex items-end gap-4 sm:inset-x-7">
            <div className="relative h-36 w-24 shrink-0 overflow-hidden rounded-xl bg-night-800 shadow-2xl ring-1 ring-white/25 sm:h-48 sm:w-32">
              <Poster movie={movie} />
            </div>
            <div className="min-w-0 flex-1 pb-1">
              <div className="mb-2 flex flex-wrap gap-1.5">
                <span className="rounded-md bg-crimson-500 px-2.5 py-1 text-[11px] font-extrabold text-on-accent">
                  {typeLabel(movie)}
                </span>
                {movie.quality && (
                  <span className="rounded-md bg-white/15 px-2.5 py-1 text-[11px] font-bold ring-1 ring-white/20 backdrop-blur-sm">
                    {movie.quality}
                  </span>
                )}
                {hasDub && (
                  <span className="rounded-md bg-flame-500 px-2.5 py-1 text-[11px] font-extrabold text-night-950">دوبله فارسی</span>
                )}
              </div>
              <h2 className="font-display text-3xl leading-tight sm:text-5xl">{movie.title}</h2>
            </div>
          </div>
        </div>

        {/* body */}
        <div className="stagger space-y-6 overflow-y-auto px-5 py-6 sm:px-8">
          {/* meta */}
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2.5 text-sm text-zinc-300">
            {movie.rating > 0 && (
              <span className="flex items-center gap-1.5 font-bold text-flame-400">
                <Star className="h-4 w-4 fill-flame-400" />
                {faRating(movie.rating)} <span className="text-[10px] font-semibold text-zinc-500">IMDb</span>
              </span>
            )}
            {movie.year > 0 && (
              <span className="flex items-center gap-1.5">
                <Calendar className="h-4 w-4 text-zinc-500" />
                {toFa(movie.year)}
              </span>
            )}
            {movie.duration && (
              <span className="flex items-center gap-1.5">
                <Clock className="h-4 w-4 text-zinc-500" />
                {movie.duration}
              </span>
            )}
            {seasons.length > 0 && (
              <span className="flex items-center gap-1.5">
                <Tv className="h-4 w-4 text-zinc-500" />
                {toFa(seasons.length)} فصل و {toFa(episodeCount)} قسمت
              </span>
            )}
          </div>
          {movie.genres.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {movie.genres.map((g) => (
                <span key={g} className="rounded-full border border-white/15 px-2.5 py-0.5 text-[11px] text-zinc-400">
                  {g}
                </span>
              ))}
            </div>
          )}

          {/* actions */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => document.getElementById("dl-box")?.scrollIntoView({ behavior: "smooth", block: "start" })}
              className="btn-accent h-12 px-6 text-sm"
            >
              <Download className="h-4 w-4" />
              دانلود
            </button>
            {movie.detailed && files.length > 0 && (
              <button
                onClick={() => setPlaying(files[0])}
                className="flex h-12 items-center gap-2 rounded-full bg-flame-500/15 px-5 text-sm font-extrabold text-flame-400 ring-1 ring-flame-500/40 transition hover:bg-flame-500/25"
              >
                <Play className="h-4 w-4 fill-current" />
                پخش آنلاین
              </button>
            )}
            {movie.trailerUrl && (
              <button
                onClick={() => onPlay(movie)}
                className="btn-ghost h-12 px-5 text-sm"
              >
                <Play className="h-4 w-4 fill-white" />
                تریلر
              </button>
            )}
            <button
              onClick={() => onToggleSave(movie)}
              className={cn(
                "flex h-12 items-center gap-2 rounded-full px-5 text-sm font-bold ring-1 transition",
                saved
                  ? "bg-flame-500/15 text-flame-400 ring-flame-500/40"
                  : "bg-white/5 text-zinc-200 ring-white/15 hover:bg-white/10"
              )}
            >
              {saved ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
              {saved ? "در لیست شماست" : "افزودن به لیست"}
            </button>
          </div>

          {/* summary */}
          <div>
            <h3 className="font-display mb-2 text-2xl">خلاصه داستان</h3>
            {!movie.detailed ? (
              <Skeleton lines={4} />
            ) : movie.description ? (
              <p className="text-sm leading-8 text-zinc-300">{movie.description}</p>
            ) : (
              <p className="text-sm text-zinc-500">خلاصه‌ای برای این عنوان ثبت نشده است.</p>
            )}
            {movie.detailError && (
              <div className="mt-3 flex items-center justify-between gap-3 rounded-xl bg-red-500/10 px-4 py-3 text-xs text-red-300 ring-1 ring-red-500/20">
                <span>دریافت اطلاعات کامل ناموفق بود.</span>
                {onRetry && (
                  <button
                    onClick={onRetry}
                    className="flex shrink-0 items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 font-bold text-white ring-1 ring-white/15 transition active:scale-95"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    تلاش دوباره
                  </button>
                )}
              </div>
            )}
          </div>

          {/* download box */}
          <div id="dl-box" className="scroll-mt-4 overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03]">
            <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
              <h3 className="font-display flex items-center gap-2 text-2xl leading-none">
                <Download className="h-5 w-5 text-flame-400" />
                دانلود
              </h3>
              {movie.detailed && files.length > 0 && <span className="text-[11px] text-zinc-500">{toFa(files.length)} فایل</span>}
            </div>

            <div className="space-y-4 p-4">
              {!movie.detailed ? (
                <Skeleton lines={3} />
              ) : dls.length === 0 ? (
                <p className="text-sm text-zinc-500">لینک دانلودی برای این عنوان پیدا نشد.</p>
              ) : (
                <>
                  {hasDub && hasSub && (
                    <Step label="۱. نسخه">
                      <div className="inline-flex rounded-full bg-white/5 p-1 ring-1 ring-white/10">
                        {(["dub", "sub"] as const).map((k) => (
                          <button
                            key={k}
                            onClick={() => { setKind(k); setQuality(null); setSeason(null); setLimit(20); }}
                            className={cn(
                              "rounded-full px-4 py-1.5 text-[12px] font-bold transition",
                              activeKind === k ? "bg-crimson-500 text-on-accent" : "text-zinc-400 hover:text-white"
                            )}
                          >
                            {k === "dub" ? "دوبله فارسی" : "زیرنویس"}
                          </button>
                        ))}
                      </div>
                    </Step>
                  )}

                  {qualities.length > 0 && (
                    <Step label={hasDub && hasSub ? "۲. کیفیت" : "۱. کیفیت"}>
                      <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
                        {qualities.map((q, i) => (
                          <Chip key={q} active={activeQ === q} onClick={() => { setQuality(q); setSeason(null); setLimit(20); }}>
                            {q.toUpperCase()}
                            {i === 0 && <span className="ms-1.5 text-[9px] opacity-70">بهترین</span>}
                          </Chip>
                        ))}
                      </div>
                    </Step>
                  )}

                  {seasonsQ.length > 1 && (
                    <Step label="فصل">
                      <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
                        {seasonsQ.map((s) => (
                          <Chip key={s} active={activeSeason === s} onClick={() => { setSeason(s); setLimit(20); }}>
                            فصل {toFa(s)}
                          </Chip>
                        ))}
                      </div>
                    </Step>
                  )}

                  {files.length > 1 && (
                    <button
                      onClick={copyAll}
                      className="flex w-full items-center justify-center gap-2 rounded-xl bg-white/5 py-2.5 text-xs font-bold text-zinc-200 ring-1 ring-white/10 transition hover:bg-white/10"
                    >
                      {copied === "__all" ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                      {copied === "__all" ? "کپی شد" : `کپی همهٔ لینک‌ها (${toFa(files.length)})`}
                    </button>
                  )}

                  <ul className="space-y-2">
                    {files.slice(0, limit).map((d, i) => (
                      <li key={`${d.link}-${i}`} className="flex items-center gap-3 rounded-xl bg-night-800/70 p-2.5 ring-1 ring-white/5">
                        <span className="grid h-9 min-w-9 shrink-0 place-items-center rounded-lg bg-white/10 px-2 text-[12px] font-black">
                          {d.episode != null ? toFa(d.episode) : (d.quality || "").toUpperCase() || "—"}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-[12px] font-bold text-zinc-200">
                            {d.episode != null ? `قسمت ${toFa(d.episode)}` : files.length > 1 ? `فایل ${toFa(i + 1)}` : "فایل فیلم"}
                          </p>
                          <p className="truncate text-[10px] text-zinc-500" dir="ltr">{d.fileName}</p>
                        </div>
                        <button
                          onClick={() => setPlaying(d)}
                          aria-label="پخش آنلاین"
                          className="shrink-0 rounded-lg bg-flame-500/15 p-2 text-flame-400 ring-1 ring-flame-500/30 transition hover:bg-flame-500/25"
                        >
                          <Play className="h-4 w-4 fill-current" />
                        </button>
                        <button
                          onClick={() => copy(d.link)}
                          aria-label="کپی لینک"
                          className="shrink-0 rounded-lg bg-white/5 p-2 text-zinc-300 ring-1 ring-white/10 transition hover:bg-white/10"
                        >
                          {copied === d.link ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                        </button>
                        <a
                          href={d.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex shrink-0 items-center gap-1 rounded-lg bg-crimson-500 px-3 py-2 text-[11px] font-extrabold text-on-accent transition hover:bg-crimson-400 active:scale-95"
                        >
                          <Download className="h-3.5 w-3.5" />
                          دانلود
                        </a>
                      </li>
                    ))}
                  </ul>
                  {files.length > limit && (
                    <button
                      onClick={() => setLimit((l) => l + 20)}
                      className="w-full rounded-xl bg-white/5 py-2.5 text-xs font-bold text-zinc-300 ring-1 ring-white/10 transition hover:bg-white/10"
                    >
                      نمایش بیشتر ({toFa(files.length - limit)} مورد دیگر)
                    </button>
                  )}
                </>
              )}
            </div>
          </div>

          {/* suggestions */}
          {similar.length > 0 && (
            <div>
              <h3 className="font-display mb-4 text-2xl">پیشنهاد برای شما</h3>
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
                {similar.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => onSelect(m)}
                    className="group relative aspect-[2/3] overflow-hidden rounded-xl ring-1 ring-white/10 transition hover:ring-crimson-500/50"
                  >
                    <Poster movie={m} className="transition-transform duration-500 group-hover:scale-110" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 to-transparent" />
                    <span className="absolute inset-x-2 bottom-2 line-clamp-2 text-right text-[11px] font-bold">{m.title}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {playing && (
        <VideoPlayer title={movie.title} file={playing} list={files} onClose={() => setPlaying(null)} onSelect={setPlaying} />
      )}
    </motion.div>
  );
}
