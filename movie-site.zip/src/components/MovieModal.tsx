import { motion } from "framer-motion";
import {
  Bookmark,
  BookmarkCheck,
  Calendar,
  Clock,
  Download,
  Play,
  Star,
  Tv,
  X,
} from "lucide-react";
import { useEffect } from "react";
import { typeLabel, type Movie } from "../data/movies";
import { useCatalog } from "../data/catalog";
import { faPercent, faRating, toFa } from "../lib/format";
import { EASE } from "../lib/motion";
import { cn } from "../utils/cn";
import PosterArt from "./PosterArt";

interface Props {
  movie: Movie;
  onClose: () => void;
  onPlay: (m: Movie) => void;
  onToggleSave: (m: Movie) => void;
  isSaved: (id: number) => boolean;
  onSelect: (m: Movie) => void;
}

const AVATAR_GRADIENTS = [
  "from-crimson-500 to-flame-500",
  "from-violet-500 to-fuchsia-500",
  "from-sky-500 to-cyan-400",
  "from-emerald-500 to-teal-400",
  "from-amber-500 to-orange-500",
];

export default function MovieModal({
  movie,
  onClose,
  onPlay,
  onToggleSave,
  isSaved,
  onSelect,
}: Props) {
  const { movies } = useCatalog();
  const saved = isSaved(movie.id);
  const similar = movies
    .filter(
      (m) => m.id !== movie.id && m.genres.some((g) => movie.genres.includes(g))
    )
    .slice(0, 4);
  const headerImage = movie.backdrop ?? movie.poster;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[70] flex items-center justify-center p-4"
    >
      <div
        className="absolute inset-0 bg-night-950/80 backdrop-blur-md"
        onClick={onClose}
      />

      <motion.div
        initial={{ opacity: 0, y: 60, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 40, scale: 0.97 }}
        transition={{ duration: 0.45, ease: EASE }}
        className="relative flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl bg-night-900 shadow-2xl ring-1 ring-white/10"
      >
        {/* header */}
        <div className="relative h-52 shrink-0 sm:h-72">
          {headerImage ? (
            <img
              src={headerImage}
              alt={movie.title}
              className="h-full w-full object-cover"
            />
          ) : (
            <PosterArt movie={movie} />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-night-900 via-night-900/25 to-night-900/10" />
          <button
            onClick={onClose}
            aria-label="بستن"
            className="absolute end-4 top-4 rounded-full bg-black/50 p-2.5 ring-1 ring-white/20 backdrop-blur-md transition hover:scale-110 hover:bg-black/80"
          >
            <X className="h-5 w-5" />
          </button>
          <div className="absolute inset-x-5 bottom-4 sm:inset-x-7">
            <div className="mb-2.5 flex flex-wrap gap-1.5">
              <span className="rounded-full bg-crimson-500/90 px-3 py-1 text-[11px] font-bold backdrop-blur-sm">
                {typeLabel(movie)}
              </span>
              <span className="rounded-full bg-white/15 px-3 py-1 text-[11px] font-bold ring-1 ring-white/20 backdrop-blur-sm">
                {movie.quality}
              </span>
              <span className="rounded-full bg-white/15 px-3 py-1 text-[11px] font-bold ring-1 ring-white/20 backdrop-blur-sm">
                {movie.age}
              </span>
              {movie.badge && (
                <span className="rounded-full bg-flame-500/90 px-3 py-1 text-[11px] font-bold text-night-950 backdrop-blur-sm">
                  {movie.badge}
                </span>
              )}
            </div>
            <h2 className="text-2xl font-black sm:text-4xl">{movie.title}</h2>
            <p className="mt-1.5 text-[10px] font-semibold tracking-[0.25em] text-zinc-400">
              {movie.originalTitle}
            </p>
          </div>
        </div>

        {/* body */}
        <div className="space-y-7 overflow-y-auto px-5 py-6 sm:px-8">
          {/* meta */}
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2.5 text-sm text-zinc-300">
            <span className="flex items-center gap-1.5 font-bold text-flame-400">
              <Star className="h-4 w-4 fill-flame-400" />
              {faRating(movie.rating)}
            </span>
            <span className="font-bold text-emerald-400">
              {faPercent(movie.match)} تطابق
            </span>
            <span className="flex items-center gap-1.5">
              <Calendar className="h-4 w-4 text-zinc-500" />
              {toFa(movie.year)}
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="h-4 w-4 text-zinc-500" />
              {movie.duration}
            </span>
            {movie.type === "series" && (
              <span className="flex items-center gap-1.5">
                <Tv className="h-4 w-4 text-zinc-500" />
                {toFa(movie.seasons ?? 1)} فصل · {toFa(movie.episodes ?? 0)} قسمت
              </span>
            )}
            <span className="flex flex-wrap gap-1.5">
              {movie.genres.map((g) => (
                <span
                  key={g}
                  className="rounded-full border border-white/15 px-2.5 py-0.5 text-[11px] text-zinc-400"
                >
                  {g}
                </span>
              ))}
            </span>
          </div>

          {/* actions */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onPlay(movie)}
              className="glow-primary flex items-center gap-2 rounded-full bg-gradient-to-l from-crimson-600 via-crimson-500 to-flame-500 px-7 py-3 text-sm font-extrabold transition-transform duration-300 hover:scale-105 active:scale-95"
            >
              <Play className="h-4.5 w-4.5 fill-white" />
              پخش {typeLabel(movie)}
            </button>
            <button
              onClick={() => onToggleSave(movie)}
              className={cn(
                "flex items-center gap-2 rounded-full px-5 py-3 text-sm font-bold ring-1 transition",
                saved
                  ? "bg-flame-500/15 text-flame-400 ring-flame-500/40"
                  : "bg-white/5 text-zinc-200 ring-white/15 hover:bg-white/10"
              )}
            >
              {saved ? (
                <BookmarkCheck className="h-4.5 w-4.5" />
              ) : (
                <Bookmark className="h-4.5 w-4.5" />
              )}
              {saved ? "در لیست شماست" : "افزودن به لیست"}
            </button>
            <button className="flex items-center gap-2 rounded-full bg-white/5 px-5 py-3 text-sm font-bold text-zinc-200 ring-1 ring-white/15 transition hover:bg-white/10">
              <Download className="h-4.5 w-4.5" />
              دانلود
            </button>
          </div>

          {/* overview */}
          <div>
            <h3 className="mb-2 text-xs font-extrabold tracking-wide text-zinc-500">
              خلاصه داستان
            </h3>
            <p className="text-sm leading-8 text-zinc-300">
              {movie.description}
            </p>
          </div>

          {/* cast & director */}
          <div>
            <h3 className="mb-4 text-xs font-extrabold tracking-wide text-zinc-500">
              عوامل و بازیگران
            </h3>
            <div className="no-scrollbar flex gap-5 overflow-x-auto pb-1">
              <div className="flex w-16 shrink-0 flex-col items-center gap-2">
                <span className="grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-night-700 to-night-800 text-base font-black ring-1 ring-white/15">
                  {movie.director.trim().charAt(0)}
                </span>
                <span className="text-center text-[10px] leading-4 text-zinc-400">
                  {movie.director}
                  <span className="block text-[9px] text-zinc-600">کارگردان</span>
                </span>
              </div>
              {movie.cast.map((c, i) => (
                <div
                  key={c}
                  className="flex w-16 shrink-0 flex-col items-center gap-2"
                >
                  <span
                    className={cn(
                      "grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br text-base font-black",
                      AVATAR_GRADIENTS[i % AVATAR_GRADIENTS.length]
                    )}
                  >
                    {c.trim().charAt(0)}
                  </span>
                  <span className="w-full truncate text-center text-[10px] leading-4 text-zinc-400">
                    {c}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* similar */}
          {similar.length > 0 && (
            <div>
              <h3 className="mb-4 text-xs font-extrabold tracking-wide text-zinc-500">
                عناوین مشابه
              </h3>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                {similar.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => onSelect(m)}
                    className="group relative aspect-[2/3] overflow-hidden rounded-xl ring-1 ring-white/10 transition hover:ring-crimson-500/50"
                  >
                    {m.poster ? (
                      <img
                        src={m.poster}
                        alt={m.title}
                        loading="lazy"
                        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                    ) : (
                      <PosterArt movie={m} />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/85 to-transparent" />
                    <span className="absolute inset-x-2 bottom-2 line-clamp-1 text-right text-[11px] font-bold">
                      {m.title}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
