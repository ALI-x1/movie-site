import { ChevronLeft, ChevronRight, type LucideIcon } from "lucide-react";
import { useRef } from "react";
import type { Movie } from "../data/movies";
import { useCatalog } from "../data/catalog";
import MovieCard from "./MovieCard";
import SectionHead from "./SectionHead";

interface Props {
  id?: string;
  title: string;
  subtitle?: string;
  icon?: LucideIcon;
  movies: Movie[];
  onOpen: (m: Movie) => void;
  onToggleSave: (m: Movie) => void;
  isSaved: (id: number) => boolean;
  onMore?: () => void;
}

export default function MovieRow({
  id,
  title,
  subtitle,
  icon,
  movies,
  onOpen,
  onToggleSave,
  isSaved,
  onMore,
}: Props) {
  const track = useRef<HTMLDivElement>(null);
  const { loading } = useCatalog();

  // RTL: "next" means scrolling visually to the left (negative left)
  const scroll = (dir: "next" | "prev") => {
    const el = track.current;
    if (!el) return;
    const amt = el.clientWidth * 0.82;
    el.scrollBy({ left: dir === "next" ? -amt : amt, behavior: "smooth" });
  };

  if (!movies.length && !loading) return null;

  return (
    <section id={id} className="relative py-8">
      <div className="mx-auto max-w-[1320px] px-4 lg:px-10">
        <SectionHead title={title} subtitle={subtitle} icon={icon}>
          {onMore && (
            <button onClick={onMore} className="btn-ghost h-10 shrink-0 px-5 text-xs">
              مشاهده همه
            </button>
          )}
          <div className="hidden gap-2 md:flex">
            <button
              onClick={() => scroll("prev")}
              aria-label="قبلی"
              className="grid h-10 w-10 place-items-center rounded-full bg-white/[0.06] ring-1 ring-white/10 transition hover:bg-crimson-500 hover:text-on-accent hover:ring-transparent"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
            <button
              onClick={() => scroll("next")}
              aria-label="بعدی"
              className="grid h-10 w-10 place-items-center rounded-full bg-white/[0.06] ring-1 ring-white/10 transition hover:bg-crimson-500 hover:text-on-accent hover:ring-transparent"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
          </div>
        </SectionHead>
      </div>

      <div className="relative">
        <div
          ref={track}
          className="no-scrollbar mx-auto flex max-w-[1320px] snap-x snap-proximity gap-4 overflow-x-auto scroll-smooth px-4 py-2 lg:px-10"
        >
          {!movies.length &&
            Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="aspect-[2/3] w-[148px] shrink-0 animate-pulse rounded-xl bg-white/5 sm:w-[172px] lg:w-[192px]" />
            ))}
          {movies.map((m) => (
            <MovieCard
              key={m.id}
              movie={m}
              onOpen={onOpen}
              saved={isSaved(m.id)}
              onToggleSave={onToggleSave}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
