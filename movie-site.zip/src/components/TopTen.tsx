import { Trophy } from "lucide-react";
import { type Movie } from "../data/movies";
import { useCatalog } from "../data/catalog";
import MovieCard from "./MovieCard";
import SectionHead from "./SectionHead";

interface Props {
  onOpen: (m: Movie) => void;
  onToggleSave: (m: Movie) => void;
  isSaved: (id: number) => boolean;
}

export default function TopTen({ onOpen, onToggleSave, isSaved }: Props) {
  const { top10 } = useCatalog();
  if (!top10.length) return null;

  return (
    <section id="top" className="relative py-10">
      <div className="mx-auto max-w-[1320px] px-4 lg:px-10">
        <SectionHead
          title="ده‌تای برتر امروز"
          subtitle="محبوب‌ترین‌های ۲۴ ساعت گذشته، بر اساس تماشای کاربران"
          icon={Trophy}
        />
      </div>

      <div className="no-scrollbar mx-auto flex max-w-[1320px] snap-x gap-5 overflow-x-auto px-4 pb-8 pt-2 lg:px-10">
        {top10.map((m, i) => (
          <MovieCard
            key={m.id}
            movie={m}
            rank={i + 1}
            onOpen={onOpen}
            saved={isSaved(m.id)}
            onToggleSave={onToggleSave}
            widthClass="w-[156px] sm:w-[180px] lg:w-[204px]"
          />
        ))}
      </div>
    </section>
  );
}
