import { Check, Copy, Download, ExternalLink, RotateCcw, RotateCw, SkipForward, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { Download as Dl } from "../data/movies";
import { copyText } from "../lib/clipboard";
import { toFa } from "../lib/format";
import { cn } from "../utils/cn";

interface Props {
  title: string;
  file: Dl;
  list: Dl[];
  onClose: () => void;
  onSelect: (d: Dl) => void;
}

const intent = (link: string, pkg: string) => {
  try {
    const u = new URL(link);
    return `intent://${u.host}${u.pathname}${u.search}#Intent;scheme=${u.protocol.replace(":", "")};package=${pkg};type=video/*;end`;
  } catch {
    return link;
  }
};
const SPEEDS = [0.75, 1, 1.25, 1.5, 2];

/* ---------- ذخیره‌ی نقطه‌ی توقف (ادامه از همان‌جا) ---------- */
const POS = "pp_pos";
const readPos = (k: string): number => {
  try { return Number(JSON.parse(localStorage.getItem(POS) || "{}")[k]) || 0; } catch { return 0; }
};
const writePos = (k: string, v: number | null) => {
  try {
    const m: Record<string, number> = JSON.parse(localStorage.getItem(POS) || "{}");
    delete m[k];
    if (v != null) m[k] = v;
    const keys = Object.keys(m);
    for (const x of keys.slice(0, Math.max(0, keys.length - 60))) delete m[x];
    localStorage.setItem(POS, JSON.stringify(m));
  } catch { /* ignore */ }
};
const clock = (s: number) => {
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = Math.floor(s % 60);
  const two = (n: number) => String(n).padStart(2, "0");
  return toFa(h ? `${h}:${two(m)}:${two(sec)}` : `${m}:${two(sec)}`);
};

export default function VideoPlayer({ title, file, list, onClose, onSelect }: Props) {
  const ref = useRef<HTMLVideoElement>(null);
  const lastSave = useRef(0);
  const [error, setError] = useState(false);
  const [buffering, setBuffering] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [copied, setCopied] = useState(false);
  const [resumed, setResumed] = useState<string | null>(null);
  const idx = list.findIndex((x) => x.link === file.link);
  const next = idx >= 0 ? list[idx + 1] : undefined;
  const src = file.link.replace(/^http:\/\//i, "https://");
  const label = file.episode != null ? `${title} - قسمت ${toFa(file.episode)}` : title;

  useEffect(() => { setError(false); setBuffering(true); setResumed(null); }, [file.link]);
  useEffect(() => {
    if (ref.current) ref.current.playbackRate = speed;
  }, [speed, file.link]);

  const skip = (sec: number) => {
    const v = ref.current;
    if (v) v.currentTime = Math.max(0, v.currentTime + sec);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") { e.stopPropagation(); onClose(); return; }
      const v = ref.current;
      if (!v || e.target === v) return; // وقتی فوکوس روی خود ویدیو است، کنترل‌های خود مرورگر کار می‌کنند
      if (e.key === "ArrowRight") { e.preventDefault(); skip(10); }
      else if (e.key === "ArrowLeft") { e.preventDefault(); skip(-10); }
      else if (e.key === " " && !(e.target instanceof HTMLButtonElement)) {
        e.preventDefault();
        if (v.paused) void v.play(); else v.pause();
      } else if (e.key.toLowerCase() === "f") {
        if (document.fullscreenElement) void document.exitFullscreen();
        else void v.requestFullscreen?.();
      }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  const copy = async () => {
    if (await copyText(file.link)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } else {
      window.prompt("لینک را کپی کنید:", file.link);
    }
  };

  const onMeta = () => {
    const v = ref.current;
    if (!v) return;
    v.playbackRate = speed;
    const p = readPos(file.link);
    if (p > 15 && v.duration && p < v.duration - 30) {
      v.currentTime = p;
      setResumed(clock(p));
      setTimeout(() => setResumed(null), 3500);
    }
  };

  const onTime = () => {
    const v = ref.current;
    if (!v) return;
    const now = Date.now();
    if (now - lastSave.current < 4000) return;
    lastSave.current = now;
    if (v.currentTime > 15) writePos(file.link, Math.floor(v.currentTime));
  };

  return createPortal(
    <div role="dialog" aria-modal="true" aria-label={label} className="fixed inset-0 z-[100] flex flex-col bg-black">
      <div className="flex items-center gap-3 bg-gradient-to-b from-black to-transparent px-4 py-3 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <button onClick={onClose} aria-label="بستن" className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white/10 ring-1 ring-white/15">
          <X className="h-5 w-5" />
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold">{label}</p>
          <p className="truncate text-[11px] text-zinc-400">
            {(file.quality || "").toUpperCase()} · {file.isDubbed ? "دوبله فارسی" : "زیرنویس"}
          </p>
        </div>
      </div>

      <div className="relative min-h-0 flex-1">
        <video
          key={file.link}
          ref={ref}
          src={src}
          controls
          autoPlay
          playsInline
          preload="metadata"
          onError={() => { setError(true); setBuffering(false); }}
          onLoadedMetadata={onMeta}
          onTimeUpdate={onTime}
          onWaiting={() => setBuffering(true)}
          onCanPlay={() => setBuffering(false)}
          onPlaying={() => setBuffering(false)}
          onEnded={() => { writePos(file.link, null); if (next) onSelect(next); }}
          className="h-full w-full bg-black object-contain"
        />
        {buffering && !error && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center">
            <span className="h-12 w-12 animate-spin rounded-full border-[3px] border-white/20 border-t-crimson-500" />
          </div>
        )}
        {resumed && (
          <div className="pointer-events-none absolute inset-x-0 top-4 flex justify-center">
            <span className="rounded-full bg-black/70 px-4 py-2 text-xs font-bold ring-1 ring-white/15 backdrop-blur-md">
              ادامه از {resumed}
            </span>
          </div>
        )}
        {error && (
          <div className="absolute inset-0 grid place-items-center bg-black/85 p-6">
            <div className="w-full max-w-sm space-y-3 text-center">
              <p className="text-sm font-bold">مرورگر نتوانست این فایل را پخش کند</p>
              <p className="text-xs leading-6 text-zinc-400">
                معمولاً به‌خاطر فرمت (MKV یا صدای AC3/DTS) یا لینک ناامن است. با یکی از پخش‌کننده‌ها باز کن:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <a href={intent(file.link, "org.videolan.vlc")} className="flex items-center justify-center gap-1.5 rounded-xl bg-orange-500 py-3 text-xs font-extrabold">
                  <ExternalLink className="h-4 w-4" /> VLC
                </a>
                <a href={intent(file.link, "com.mxtech.videoplayer.ad")} className="flex items-center justify-center gap-1.5 rounded-xl bg-sky-500 py-3 text-xs font-extrabold">
                  <ExternalLink className="h-4 w-4" /> MX Player
                </a>
                <a href={file.link} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-1.5 rounded-xl bg-white/10 py-3 text-xs font-bold ring-1 ring-white/15">
                  <Download className="h-4 w-4" /> دانلود
                </a>
                <button onClick={copy} className="flex items-center justify-center gap-1.5 rounded-xl bg-white/10 py-3 text-xs font-bold ring-1 ring-white/15">
                  {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />} کپی لینک
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="no-scrollbar flex items-center gap-2 overflow-x-auto bg-gradient-to-t from-black to-transparent px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <button onClick={() => skip(-10)} aria-label="۱۰ ثانیه عقب" className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/10 ring-1 ring-white/15 active:scale-95">
          <RotateCcw className="h-4 w-4" />
        </button>
        <button onClick={() => skip(10)} aria-label="۱۰ ثانیه جلو" className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-white/10 ring-1 ring-white/15 active:scale-95">
          <RotateCw className="h-4 w-4" />
        </button>
        <span className="ms-1 shrink-0 text-[11px] text-zinc-500">سرعت</span>
        {SPEEDS.map((s) => (
          <button
            key={s}
            onClick={() => setSpeed(s)}
            className={cn(
              "shrink-0 rounded-full px-3 py-1.5 text-[11px] font-bold ring-1 transition",
              speed === s ? "bg-gradient-to-l from-crimson-600 to-flame-500 text-white ring-transparent" : "bg-white/5 text-zinc-300 ring-white/10"
            )}
          >
            {s}x
          </button>
        ))}
        {next && (
          <button
            onClick={() => onSelect(next)}
            className="ms-auto flex shrink-0 items-center gap-1.5 rounded-full bg-white/10 px-4 py-1.5 text-[11px] font-bold ring-1 ring-white/15"
          >
            <SkipForward className="h-3.5 w-3.5" />
            {next.episode != null ? `قسمت ${toFa(next.episode)}` : "بعدی"}
          </button>
        )}
      </div>
    </div>,
    document.body
  );
}
