import { Check, Copy, Download, ExternalLink, SkipForward, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import type { Download as Dl } from "../data/movies";
import { toFa } from "../lib/format";
import { cn } from "../utils/cn";

interface Props {
  title: string;
  file: Dl;
  list: Dl[];
  onClose: () => void;
  onSelect: (d: Dl) => void;
}

const intent = (link: string, pkg: string) => {
  try {
    const u = new URL(link);
    return `intent://${u.host}${u.pathname}${u.search}#Intent;scheme=${u.protocol.replace(":", "")};package=${pkg};type=video/*;end`;
  } catch {
    return link;
  }
};
const SPEEDS = [0.75, 1, 1.25, 1.5, 2];

export default function VideoPlayer({ title, file, list, onClose, onSelect }: Props) {
  const ref = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [copied, setCopied] = useState(false);
  const idx = list.findIndex((x) => x.link === file.link);
  const next = idx >= 0 ? list[idx + 1] : undefined;
  const src = file.link.replace(/^http:\/\//i, "https://");
  const label = file.episode != null ? `${title} - قسمت ${toFa(file.episode)}` : title;

  useEffect(() => setError(false), [file.link]);
  useEffect(() => {
    if (ref.current) ref.current.playbackRate = speed;
  }, [speed, file.link]);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") { e.stopPropagation(); onClose(); }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(file.link);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      window.prompt("لینک را کپی کنید:", file.link);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[100] flex flex-col bg-black">
      <div className="flex items-center gap-3 bg-gradient-to-b from-black to-transparent px-4 py-3">
        <button onClick={onClose} aria-label="بستن" className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white/10 ring-1 ring-white/15">
          <X className="h-5 w-5" />
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold">{label}</p>
          <p className="truncate text-[11px] text-zinc-400">
            {(file.quality || "").toUpperCase()} · {file.isDubbed ? "دوبله فارسی" : "زیرنویس"}
          </p>
        </div>
      </div>

      <div className="relative min-h-0 flex-1">
        <video
          key={file.link}
          ref={ref}
          src={src}
          controls
          autoPlay
          playsInline
          preload="metadata"
          onError={() => setError(true)}
          onLoadedMetadata={() => { if (ref.current) ref.current.playbackRate = speed; }}
          onEnded={() => next && onSelect(next)}
          className="h-full w-full bg-black object-contain"
        />
        {error && (
          <div className="absolute inset-0 grid place-items-center bg-black/85 p-6">
            <div className="w-full max-w-sm space-y-3 text-center">
              <p className="text-sm font-bold">مرورگر نتوانست این فایل را پخش کند</p>
              <p className="text-xs leading-6 text-zinc-400">
                معمولاً به‌خاطر فرمت (MKV یا صدای AC3/DTS) یا لینک ناامن است. با یکی از پخش‌کننده‌ها باز کن:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <a href={intent(file.link, "org.videolan.vlc")} className="flex items-center justify-center gap-1.5 rounded-xl bg-orange-500 py-3 text-xs font-extrabold">
                  <ExternalLink className="h-4 w-4" /> VLC
                </a>
                <a href={intent(file.link, "com.mxtech.videoplayer.ad")} className="flex items-center justify-center gap-1.5 rounded-xl bg-sky-500 py-3 text-xs font-extrabold">
                  <ExternalLink className="h-4 w-4" /> MX Player
                </a>
                <a href={file.link} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-1.5 rounded-xl bg-white/10 py-3 text-xs font-bold ring-1 ring-white/15">
                  <Download className="h-4 w-4" /> دانلود
                </a>
                <button onClick={copy} className="flex items-center justify-center gap-1.5 rounded-xl bg-white/10 py-3 text-xs font-bold ring-1 ring-white/15">
                  {copied ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />} کپی لینک
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 overflow-x-auto bg-gradient-to-t from-black to-transparent px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
        <span className="shrink-0 text-[11px] text-zinc-500">سرعت</span>
        {SPEEDS.map((s) => (
          <button
            key={s}
            onClick={() => setSpeed(s)}
            className={cn(
              "shrink-0 rounded-full px-3 py-1.5 text-[11px] font-bold ring-1 transition",
              speed === s ? "bg-gradient-to-l from-crimson-600 to-flame-500 text-white ring-transparent" : "bg-white/5 text-zinc-300 ring-white/10"
            )}
          >
            {s}x
          </button>
        ))}
        {next && (
          <button
            onClick={() => onSelect(next)}
            className="ms-auto flex shrink-0 items-center gap-1.5 rounded-full bg-white/10 px-4 py-1.5 text-[11px] font-bold ring-1 ring-white/15"
          >
            <SkipForward className="h-3.5 w-3.5" />
            {next.episode != null ? `قسمت ${toFa(next.episode)}` : "بعدی"}
          </button>
        )}
      </div>
    </div>,
    document.body
  );
}
