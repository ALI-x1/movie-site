import { motion } from "framer-motion";
import { BadgeCheck, ExternalLink, X } from "lucide-react";
import { useEffect, useState } from "react";
import { typeLabel, type Movie } from "../data/movies";
import { EASE } from "../lib/motion";

interface Props {
  movie: Movie;
  onClose: () => void;
}

const ytId = (u?: string) =>
  u?.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/))([\w-]{11})/)?.[1];

export default function PlayerModal({ movie, onClose }: Props) {
  const [failed, setFailed] = useState(false);
  const yt = ytId(movie.trailerUrl);

  // Escape فقط پخش‌کننده را می‌بندد، نه مودال زیرش را
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") { e.stopPropagation(); onClose(); }
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      role="dialog"
      aria-modal="true"
      aria-label={`تریلر ${movie.title}`}
      className="fixed inset-0 z-[80] bg-night-950/95 backdrop-blur-xl"
    >
      <div className="flex h-full flex-col">
        <div className="mx-auto flex w-full max-w-6xl shrink-0 items-center justify-between px-4 py-5">
          <div className="flex min-w-0 items-center gap-3">
            <span className="hidden items-center gap-1.5 rounded-full bg-flame-500/15 px-3 py-1.5 text-xs font-bold text-flame-400 ring-1 ring-flame-500/30 sm:flex">
              <BadgeCheck className="h-3.5 w-3.5" />
              پیش‌نمایش رسمی
            </span>
            <h3 className="truncate text-sm font-bold sm:text-lg">
              {movie.title}{" "}
              <span className="text-xs font-medium text-zinc-500">({typeLabel(movie)})</span>
            </h3>
          </div>
          <button
            onClick={onClose}
            aria-label="بستن"
            className="rounded-full bg-white/5 p-2.5 ring-1 ring-white/15 transition hover:scale-110 hover:bg-white/15"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex flex-1 items-center justify-center px-4 pb-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96 }}
            transition={{ duration: 0.45, ease: EASE }}
            className="glow-primary relative w-full max-w-6xl overflow-hidden rounded-3xl bg-black ring-1 ring-white/15"
          >
            {yt ? (
              <iframe
                src={`https://www.youtube-nocookie.com/embed/${yt}?autoplay=1&rel=0`}
                title={movie.title}
                allow="autoplay; fullscreen; picture-in-picture"
                allowFullScreen
                className="aspect-video w-full"
              />
            ) : (
              <video
                src={movie.trailerUrl}
                poster={movie.backdrop ?? movie.poster}
                controls
                autoPlay
                playsInline
                onError={() => setFailed(true)}
                className="aspect-video w-full"
              />
            )}
            {failed && (
              <div className="absolute inset-0 grid place-items-center bg-black/85 p-6 text-center">
                <div className="space-y-3">
                  <p className="text-sm font-bold">پخش تریلر در مرورگر ممکن نشد</p>
                  {movie.trailerUrl && (
                    <a
                      href={movie.trailerUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mx-auto flex w-fit items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-xs font-bold ring-1 ring-white/20"
                    >
                      <ExternalLink className="h-4 w-4" />
                      باز کردن در تب جدید
                    </a>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
