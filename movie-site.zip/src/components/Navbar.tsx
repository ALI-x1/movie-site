import { AnimatePresence, motion } from "framer-motion";
import { Bookmark, Clapperboard, Film, LayoutGrid, Search, Trophy, Tv, X, type LucideIcon } from "lucide-react";
import { useEffect, useState } from "react";
import ThemePicker from "./ThemePicker";
import { toFa } from "../lib/format";
import { EASE } from "../lib/motion";
import { cn } from "../utils/cn";

const LINKS: { label: string; id: string; icon: LucideIcon }[] = [
  { label: "خانه", id: "home", icon: Clapperboard },
  { label: "فیلم‌ها", id: "movies", icon: Film },
  { label: "سریال‌ها", id: "series", icon: Tv },
  { label: "۲۵۰ برتر", id: "top", icon: Trophy },
  { label: "دسته‌بندی", id: "categories", icon: LayoutGrid },
];

interface Props {
  query: string;
  onQueryChange: (q: string) => void;
  myListCount: number;
  onMyListClick: () => void;
  onNavigate: (id: string) => void;
}

export default function Navbar({ query, onQueryChange, myListCount, onMyListClick, onNavigate }: Props) {
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      let best: string | null = null;
      let bestTop = -Infinity;
      for (const l of LINKS) {
        const el = document.getElementById(l.id);
        if (!el) continue;
        const top = el.getBoundingClientRect().top;
        if (top <= 160 && top > bestTop) { best = l.id; bestTop = top; }
      }
      setActive(best ?? "home");
    };
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      if (!raf) raf = requestAnimationFrame(update);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  const nav = (id: string) => onNavigate(id);

  const closeSearch = () => {
    setSearchOpen(false);
    onQueryChange("");
  };

  const isActive = (id: string) => active === id && !query;

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3 lg:px-8 lg:pt-4">
        <div
          className={cn(
            "mx-auto flex h-14 max-w-[1320px] items-center gap-3 rounded-2xl border px-3 transition-all duration-500 lg:h-[60px] lg:gap-5 lg:rounded-full lg:ps-4 lg:pe-3",
            scrolled || searchOpen
              ? "border-white/10 bg-night-900/80 shadow-[0_14px_44px_-14px_rgba(0,0,0,0.85)] backdrop-blur-xl"
              : "border-transparent bg-transparent"
          )}
        >
          {/* logo */}
          <a
            href="#home"
            onClick={(e) => { e.preventDefault(); nav("home"); }}
            className="flex shrink-0 items-center gap-2.5"
            aria-label="پرده‌پلاس"
          >
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-crimson-500 text-on-accent">
              <Clapperboard className="h-5 w-5" />
            </span>
            <span className="font-display text-[1.65rem] leading-none">پرده‌پلاس</span>
          </a>

          {/* desktop links */}
          <ul className="mx-auto hidden items-center gap-1 lg:flex">
            {LINKS.map((l) => (
              <li key={l.id}>
                <a
                  href={"#" + l.id}
                  onClick={(e) => { e.preventDefault(); nav(l.id); }}
                  aria-current={isActive(l.id) ? "true" : undefined}
                  className={cn(
                    "relative isolate block rounded-full px-4 py-2 text-sm font-semibold transition-colors",
                    isActive(l.id) ? "text-white" : "text-zinc-400 hover:text-white"
                  )}
                >
                  {isActive(l.id) && (
                    <motion.span
                      layoutId="nav-pill"
                      className="absolute inset-0 -z-10 rounded-full bg-white/10"
                      transition={{ duration: 0.4, ease: EASE }}
                    />
                  )}
                  {l.label}
                </a>
              </li>
            ))}
          </ul>

          {/* actions */}
          <div className="ms-auto flex items-center gap-2 lg:ms-0">
            <label className="hidden h-10 w-44 items-center gap-2 rounded-full bg-white/[0.06] px-3.5 ring-1 ring-white/10 transition-all duration-500 focus-within:w-64 focus-within:bg-white/10 focus-within:ring-crimson-500/60 md:flex">
              <Search className="h-4 w-4 shrink-0 text-zinc-400" />
              <input
                value={query}
                onChange={(e) => onQueryChange(e.target.value)}
                onKeyDown={(e) => e.key === "Escape" && onQueryChange("")}
                placeholder="جستجوی فیلم، سریال..."
                enterKeyHint="search"
                className="w-full bg-transparent text-sm outline-none placeholder:text-zinc-500"
              />
              {query && (
                <button onClick={() => onQueryChange("")} aria-label="پاک کردن">
                  <X className="h-3.5 w-3.5 text-zinc-400 transition hover:text-white" />
                </button>
              )}
            </label>

            <button
              onClick={() => (searchOpen ? closeSearch() : setSearchOpen(true))}
              className="grid h-10 w-10 place-items-center rounded-full bg-white/[0.06] ring-1 ring-white/10 transition hover:ring-crimson-500/60 md:hidden"
              aria-label="جستجو"
            >
              {searchOpen ? <X className="h-4 w-4" /> : <Search className="h-4 w-4" />}
            </button>

            <ThemePicker />

            <button
              onClick={onMyListClick}
              className="relative grid h-10 w-10 place-items-center rounded-full bg-white/[0.06] ring-1 ring-white/10 transition hover:ring-crimson-500/60"
              aria-label="لیست من"
            >
              <Bookmark className="h-4 w-4" />
              {myListCount > 0 && (
                <span className="absolute -end-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-flame-500 px-1 text-[10px] font-extrabold text-night-950 shadow-lg">
                  {toFa(myListCount)}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* mobile search */}
        <AnimatePresence initial={false}>
          {searchOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3, ease: EASE }}
              className="overflow-hidden md:hidden"
            >
              <label className="mt-2 flex h-12 items-center gap-2 rounded-2xl border border-white/10 bg-night-900/90 px-4 backdrop-blur-xl focus-within:border-crimson-500/60">
                <Search className="h-4 w-4 shrink-0 text-zinc-400" />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => onQueryChange(e.target.value)}
                  placeholder="جستجوی فیلم، سریال..."
                  enterKeyHint="search"
                  className="w-full bg-transparent text-base outline-none placeholder:text-zinc-500"
                />
                {query && (
                  <button onClick={() => onQueryChange("")} aria-label="پاک کردن">
                    <X className="h-4 w-4 text-zinc-400" />
                  </button>
                )}
              </label>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* mobile dock */}
      <nav
        aria-label="ناوبری اصلی"
        className="fixed inset-x-3 bottom-3 z-50 lg:hidden"
        style={{ marginBottom: "env(safe-area-inset-bottom)" }}
      >
        <ul className="mx-auto flex max-w-md items-stretch gap-1 rounded-2xl border border-white/10 bg-night-900/90 p-1.5 shadow-[0_20px_50px_-10px_rgba(0,0,0,0.9)] backdrop-blur-xl">
          {LINKS.map((l) => (
            <li key={l.id} className="flex-1">
              <a
                href={"#" + l.id}
                onClick={(e) => { e.preventDefault(); nav(l.id); }}
                aria-current={isActive(l.id) ? "true" : undefined}
                className={cn(
                  "relative isolate flex flex-col items-center gap-1 rounded-xl py-2 text-[10px] font-bold transition-colors",
                  isActive(l.id) ? "text-flame-400" : "text-zinc-500"
                )}
              >
                {isActive(l.id) && (
                  <motion.span
                    layoutId="dock-pill"
                    className="absolute inset-0 -z-10 rounded-xl bg-white/10"
                    transition={{ duration: 0.4, ease: EASE }}
                  />
                )}
                <l.icon className="h-5 w-5" />
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </>
  );
}
