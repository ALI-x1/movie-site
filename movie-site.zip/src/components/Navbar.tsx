import { AnimatePresence, motion } from "framer-motion";
import { Bookmark, Clapperboard, Menu, Search, X } from "lucide-react";
import { useEffect, useState } from "react";
import ThemePicker from "./ThemePicker";
import { toFa } from "../lib/format";
import { EASE } from "../lib/motion";
import { cn } from "../utils/cn";

const LINKS = [
  { label: "خانه", id: "home" },
  { label: "فیلم‌ها", id: "movies" },
  { label: "سریال‌ها", id: "series" },
  { label: "برترین‌ها", id: "top" },
  { label: "ژانرها", id: "genres" },
];

interface Props {
  query: string;
  onQueryChange: (q: string) => void;
  myListCount: number;
  onMyListClick: () => void;
  onNavigate: (id: string) => void;
}

export default function Navbar({ query, onQueryChange, myListCount, onMyListClick, onNavigate }: Props) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      let best: string | null = null;
      let bestTop = -Infinity;
      for (const l of LINKS) {
        const el = document.getElementById(l.id);
        if (!el) continue;
        const top = el.getBoundingClientRect().top;
        if (top <= 140 && top > bestTop) { best = l.id; bestTop = top; }
      }
      setActive(best ?? "home");
    };
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      if (!raf) raf = requestAnimationFrame(update);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  const nav = (id: string) => {
    setOpen(false);
    onNavigate(id);
  };

  const closeSearch = () => {
    setSearchOpen(false);
    onQueryChange("");
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        scrolled || open || searchOpen
          ? "border-b border-white/5 bg-night-950/85 backdrop-blur-xl"
          : "bg-gradient-to-b from-night-950/80 to-transparent"
      )}
    >
      <nav className="mx-auto flex h-16 max-w-[1440px] items-center gap-5 px-4 lg:h-[76px] lg:px-10">
        {/* logo */}
        <a
          href="#home"
          onClick={(e) => { e.preventDefault(); nav("home"); }}
          className="flex shrink-0 items-center gap-2.5"
        >
          <span className="glow-primary grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-crimson-500 to-flame-500">
            <Clapperboard className="h-5 w-5 text-white" />
          </span>
          <span className="text-xl font-black tracking-tight">
            پرده
            <span className="bg-gradient-to-l from-crimson-400 to-flame-400 bg-clip-text text-transparent">‌پلاس</span>
          </span>
        </a>

        {/* desktop links */}
        <ul className="hidden items-center gap-7 text-sm font-medium lg:flex">
          {LINKS.map((l) => (
            <li key={l.id}>
              <a
                href={"#" + l.id}
                onClick={(e) => { e.preventDefault(); nav(l.id); }}
                aria-current={active === l.id && !query ? "true" : undefined}
                className={cn(
                  "relative pb-1 transition-colors after:absolute after:-bottom-0.5 after:start-0 after:h-0.5 after:rounded-full after:bg-gradient-to-l after:from-crimson-500 after:to-flame-500 after:transition-all after:duration-300 hover:text-white hover:after:w-full",
                  active === l.id && !query ? "text-white after:w-full" : "text-zinc-300 after:w-0"
                )}
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* actions */}
        <div className="ms-auto flex items-center gap-2.5">
          <label className="hidden h-10 w-44 items-center gap-2 rounded-full bg-white/5 px-3.5 ring-1 ring-white/10 transition-all duration-500 focus-within:w-64 focus-within:bg-white/10 focus-within:ring-crimson-500/50 md:flex">
            <Search className="h-4 w-4 shrink-0 text-zinc-400" />
            <input
              value={query}
              onChange={(e) => onQueryChange(e.target.value)}
              onKeyDown={(e) => e.key === "Escape" && onQueryChange("")}
              placeholder="جستجوی فیلم، سریال..."
              enterKeyHint="search"
              className="w-full bg-transparent text-sm outline-none placeholder:text-zinc-500"
            />
            {query && (
              <button onClick={() => onQueryChange("")} aria-label="پاک کردن">
                <X className="h-3.5 w-3.5 text-zinc-400 transition hover:text-white" />
              </button>
            )}
          </label>

          <button
            onClick={() => (searchOpen ? closeSearch() : (setSearchOpen(true), setOpen(false)))}
            className="grid h-10 w-10 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition hover:ring-crimson-500/50 md:hidden"
            aria-label="جستجو"
          >
            {searchOpen ? <X className="h-4 w-4" /> : <Search className="h-4 w-4" />}
          </button>
          <ThemePicker />

          <button
            onClick={onMyListClick}
            className="relative grid h-10 w-10 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition hover:ring-crimson-500/60"
            aria-label="لیست من"
          >
            <Bookmark className="h-4 w-4" />
            {myListCount > 0 && (
              <span className="absolute -end-1 -top-1 grid h-5 w-5 place-items-center rounded-full bg-crimson-500 text-[10px] font-bold shadow-lg">
                {toFa(myListCount)}
              </span>
            )}
          </button>

          <button
            onClick={() => { setOpen(!open); setSearchOpen(false); }}
            className="grid h-10 w-10 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 lg:hidden"
            aria-label="منو"
            aria-expanded={open}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {/* mobile search */}
      <AnimatePresence initial={false}>
        {searchOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: EASE }}
            className="overflow-hidden border-t border-white/5 md:hidden"
          >
            <label className="m-3 flex h-11 items-center gap-2 rounded-2xl bg-white/5 px-4 ring-1 ring-white/10 focus-within:ring-crimson-500/50">
              <Search className="h-4 w-4 shrink-0 text-zinc-400" />
              <input
                autoFocus
                value={query}
                onChange={(e) => onQueryChange(e.target.value)}
                placeholder="جستجوی فیلم، سریال..."
                enterKeyHint="search"
                className="w-full bg-transparent text-base outline-none placeholder:text-zinc-500"
              />
              {query && (
                <button onClick={() => onQueryChange("")} aria-label="پاک کردن">
                  <X className="h-4 w-4 text-zinc-400" />
                </button>
              )}
            </label>
          </motion.div>
        )}
      </AnimatePresence>

      {/* mobile menu */}
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: EASE }}
            className="overflow-hidden border-t border-white/5 lg:hidden"
          >
            <div className="space-y-1 px-4 py-4">
              {LINKS.map((l) => (
                <a
                  key={l.id}
                  href={"#" + l.id}
                  onClick={(e) => { e.preventDefault(); nav(l.id); }}
                  className={cn(
                    "block rounded-xl px-3 py-3 text-sm font-medium transition hover:bg-white/5 hover:text-white",
                    active === l.id && !query ? "bg-white/5 text-white" : "text-zinc-300"
                  )}
                >
                  {l.label}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
