import { motion } from "framer-motion";
import { Clapperboard } from "lucide-react";
import { EASE } from "../lib/motion";

/** ورودی سایت: پرده‌ی سینما بسته است و بعد از لحظه‌ای دو طرف کنار می‌رود */
export default function Curtain({ open }: { open: boolean }) {
  const move = { duration: 1.05, ease: EASE };
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-[100] overflow-hidden">
      <motion.div
        className="curtain absolute inset-y-0 start-0 w-1/2 border-e-[3px] border-flame-500/80"
        initial={{ x: "0%" }}
        animate={{ x: open ? "100%" : "0%" }}
        transition={move}
      />
      <motion.div
        className="curtain absolute inset-y-0 end-0 w-1/2 border-s-[3px] border-flame-500/80"
        initial={{ x: "0%" }}
        animate={{ x: open ? "-100%" : "0%" }}
        transition={move}
      />
      <motion.div
        className="absolute inset-0 flex flex-col items-center justify-center gap-5"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: open ? 0 : 1, scale: open ? 1.12 : 1 }}
        transition={{ duration: open ? 0.45 : 0.7, ease: EASE, delay: open ? 0 : 0.15 }}
      >
        <span className="grid h-20 w-20 place-items-center rounded-3xl bg-flame-500 text-night-950 shadow-[0_20px_50px_-10px_rgba(0,0,0,0.7)]">
          <Clapperboard className="h-10 w-10" />
        </span>
        <div className="text-center">
          <p className="font-display text-5xl leading-none text-white drop-shadow-[0_4px_20px_rgba(0,0,0,0.5)]">پرده‌پلاس</p>
          <p className="mt-3 text-sm text-white/80">دنیای فیلم و سریال، بدون مرز</p>
        </div>
      </motion.div>
    </div>
  );
}
