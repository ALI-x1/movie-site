import { useEffect, useRef, useState } from "react";
import type { Movie } from "../data/movies";
import { cn } from "../utils/cn";
import PosterArt from "./PosterArt";

/** تصویر امن: referrer نمی‌فرستد (ضد hotlink)، تنبل لود می‌شود، با fade ظاهر می‌شود و اگر نیامد طرح گرادیانی نشان می‌دهد. */
export default function Poster({ movie, src, className = "" }: { movie: Movie; src?: string; className?: string }) {
  const url = src ?? movie.poster;
  const [state, setState] = useState<"loading" | "ok" | "failed">("loading");
  const img = useRef<HTMLImageElement>(null);

  useEffect(() => {
    setState("loading");
    const el = img.current;
    if (el?.complete && el.naturalWidth > 0) setState("ok");
  }, [url]);

  if (!url || state === "failed") return <PosterArt movie={movie} />;
  return (
    <>
      {state === "loading" && <div className="absolute inset-0 animate-pulse bg-white/[0.05]" />}
      <img
        ref={img}
        src={url}
        alt={movie.title}
        loading="lazy"
        decoding="async"
        referrerPolicy="no-referrer"
        onLoad={() => setState("ok")}
        onError={() => setState("failed")}
        className={cn(
          "absolute inset-0 h-full w-full object-cover transition-opacity duration-500",
          state === "ok" ? "opacity-100" : "opacity-0",
          className
        )}
      />
    </>
  );
}
