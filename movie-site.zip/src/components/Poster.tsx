import { useEffect, useState } from "react";
import type { Movie } from "../data/movies";
import PosterArt from "./PosterArt";

/** تصویر امن: referrer نمی‌فرستد (ضد hotlink)، تنبل لود می‌شود و اگر نیامد طرح گرادیانی نشان می‌دهد. */
export default function Poster({ movie, src, className = "" }: { movie: Movie; src?: string; className?: string }) {
  const url = src ?? movie.poster;
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [url]);
  if (!url || failed) return <PosterArt movie={movie} />;
  return (
    <img
      src={url}
      alt={movie.title}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={"absolute inset-0 h-full w-full object-cover " + className}
    />
  );
}
