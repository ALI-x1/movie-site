const ITEMS = [
  "پخش بی‌وقفه",
  "اکشن",
  "کیفیت 4K",
  "درام",
  "دوبلهٔ اختصاصی",
  "علمی‌تخیلی",
  "زیرنویس فارسی",
  "فانتزی",
  "سینمای جهان",
  "معمایی",
];

/** تابلوی سینما: نوار رنگی با لامپ‌های بالا و پایین و متن‌های متحرک */
export default function Marquee() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <div className="group relative my-10 bg-crimson-700 py-3.5">
      <div className="bulbs absolute inset-x-0 top-1" aria-hidden />
      <div className="bulbs absolute inset-x-0 bottom-1" aria-hidden />
      <div className="overflow-hidden py-2.5">
        <div className="animate-marquee flex w-max items-center group-hover:[animation-play-state:paused]">
          {row.map((item, i) => (
            <div key={i} className="flex items-center">
              <span className="font-display whitespace-nowrap px-6 text-2xl text-white md:text-3xl">{item}</span>
              <span aria-hidden className="h-2 w-2 shrink-0 rotate-45 bg-flame-400" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
