import { AnimatePresence, motion } from "framer-motion";
import { Check, Palette } from "lucide-react";
import { useState } from "react";
import { createPortal } from "react-dom";
import { EASE } from "../lib/motion";
import { THEMES, applyTheme, currentTheme } from "../lib/themes";
import { cn } from "../utils/cn";

export default function ThemePicker() {
  const [open, setOpen] = useState(false);
  const [id, setId] = useState(currentTheme());
  const pick = (t: string) => { applyTheme(t); setId(t); };

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="تغییر تم"
        className="grid h-10 w-10 place-items-center rounded-full bg-white/5 ring-1 ring-white/10 transition hover:ring-crimson-500/50"
      >
        <Palette className="h-4 w-4" />
      </button>
      {createPortal(
        <AnimatePresence>
          {open && (
            <motion.div
              key="theme-wrap"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25, ease: EASE }}
              className="fixed inset-0 z-[90]"
            >
              <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" onClick={() => setOpen(false)} />
              <div className="stagger absolute inset-x-4 top-[72px] rounded-3xl bg-night-850/95 p-4 shadow-2xl ring-1 ring-white/10 backdrop-blur-xl sm:inset-x-auto sm:end-10 sm:w-[380px]">
                <p className="mb-4 text-sm font-extrabold">انتخاب تم</p>
                <div className="grid grid-cols-5 gap-x-2 gap-y-4">
                  {THEMES.map((t) => (
                    <button key={t.id} onClick={() => pick(t.id)} className="group flex flex-col items-center gap-1.5">
                      <span
                        className={cn(
                          "grid h-12 w-12 place-items-center rounded-full ring-2 transition",
                          id === t.id ? "scale-110 ring-white" : "ring-white/10 group-hover:ring-white/40"
                        )}
                        style={{ background: `linear-gradient(135deg, ${t.crimson[2]}, ${t.flame[2]})` }}
                      >
                        {id === t.id && <Check className="h-5 w-5 text-white drop-shadow" />}
                      </span>
                      <span className="text-[10px] font-semibold text-zinc-400">{t.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>,
        document.body
      )}
    </>
  );
}
