import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { API_BASE, fetchHome, toMovie, type ApiItem, type Home } from "../lib/api";
import { copyText } from "../lib/clipboard";
import type { Movie } from "./movies";

interface Catalog {
  movies: Movie[]; heroSlides: Movie[]; top10: Movie[]; trending: Movie[];
  newReleases: Movie[]; seriesList: Movie[]; loading: boolean; error: boolean;
  stale: boolean; message: string; log: string; reload: () => void;
}
const initial: Catalog = {
  movies: [], heroSlides: [], top10: [], trending: [], newReleases: [],
  seriesList: [], loading: true, error: false, stale: false, message: "", log: "",
  reload: () => {},
};
const Ctx = createContext<Catalog>(initial);
export const useCatalog = () => useContext(Ctx);

const CACHE_KEY = "pp_home_v1";
const readCache = (): Home | null => {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? (JSON.parse(raw) as Home) : null;
  } catch { return null; }
};
const writeCache = (h: Home) => {
  try {
    const copy: Home = { ...h };
    delete copy._diag;
    localStorage.setItem(CACHE_KEY, JSON.stringify(copy));
  } catch { /* ignore */ }
};

const list = (a?: ApiItem[]) => (Array.isArray(a) ? a : []);
const interleave = <T,>(a: T[], b: T[]): T[] => {
  const out: T[] = [];
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    if (i < a.length) out.push(a[i]);
    if (i < b.length) out.push(b[i]);
  }
  return out;
};

function build(h: Home) {
  const m = list(h.movies).map((i) => toMovie(i, "movie"));
  const s = list(h.series).map((i) => toMovie(i, "series"));
  const tm = list(h.topMovies).map((i) => toMovie(i, "movie"));
  const ts = list(h.topSeries).map((i) => toMovie(i, "series"));
  const seen = new Set<number>();
  const all = [...m, ...s, ...tm, ...ts].filter((x) => !seen.has(x.id) && seen.add(x.id));
  const hero = [...m, ...s].filter((x) => x.poster).slice(0, 6);
  return {
    movies: all,
    heroSlides: hero,
    top10: (tm.length ? tm : m).slice(0, 10),
    trending: (ts.length ? interleave(m, ts) : m).slice(0, 12),
    newReleases: m,
    seriesList: s.length ? s : ts,
  };
}

const mkLog = (extra: Record<string, unknown>) =>
  JSON.stringify(
    { time: new Date().toISOString(), api: API_BASE || "(خالی)", page: location.href, ua: navigator.userAgent, ...extra },
    null,
    2,
  );

function DebugBanner({ message, log }: { message: string; log: string }) {
  const [st, setSt] = useState<"idle" | "ok" | "fail">("idle");
  const [hidden, setHidden] = useState(false);
  const { reload } = useCatalog();
  if (hidden) return null;
  return (
    <div
      style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 99999, background: "#7f1d1d", color: "#fff", padding: "10px 12px calc(10px + env(safe-area-inset-bottom))", fontSize: 12 }}
    >
      <div style={{ direction: "rtl", textAlign: "right", wordBreak: "break-word" }}>⚠ {message}</div>
      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        <button
          onClick={reload}
          style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: 0, background: "#fff", color: "#7f1d1d", fontWeight: 700, fontSize: 14 }}
        >
          ↻ تلاش دوباره
        </button>
        <button
          onClick={async () => setSt((await copyText(log)) ? "ok" : "fail")}
          style={{ flex: 1, padding: "10px 0", borderRadius: 10, border: 0, background: "rgba(255,255,255,.18)", color: "#fff", fontWeight: 700, fontSize: 14 }}
        >
          {st === "ok" ? "✓ کپی شد" : "📋 کپی لاگ"}
        </button>
        <button
          onClick={() => setHidden(true)}
          aria-label="بستن"
          style={{ width: 44, borderRadius: 10, border: 0, background: "rgba(255,255,255,.18)", color: "#fff", fontSize: 16 }}
        >
          ✕
        </button>
      </div>
      {st === "fail" && (
        <textarea
          readOnly
          value={log}
          onFocus={(e) => e.currentTarget.select()}
          style={{ marginTop: 8, width: "100%", height: 120, direction: "ltr", fontSize: 11, color: "#000" }}
        />
      )}
    </div>
  );
}

export function CatalogProvider({ children }: { children: ReactNode }) {
  // نمایش فوری آخرین داده‌ی ذخیره‌شده، همزمان با گرفتن داده‌ی تازه از ووکر
  const [state, setState] = useState<Omit<Catalog, "reload">>(() => {
    const c = readCache();
    if (!c) return initial;
    const b = build(c);
    return b.movies.length ? { ...initial, ...b, loading: false, stale: true } : initial;
  });
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let live = true;
    fetchHome()
      .then((h) => {
        if (!live) return;
        const b = build(h);
        if (!b.movies.length) {
          setState((p) =>
            p.movies.length
              ? { ...p, loading: false }
              : {
                  ...p, loading: false, error: true,
                  message: `ووکر جواب داد ولی همه لیست‌ها خالی‌اند (فیلم ${list(h.movies).length}، سریال ${list(h.series).length}). دکمه‌ی «کپی لاگ» رو بزن و لاگ رو برام بفرست.`,
                  log: mkLog({ result: "empty", response: h }),
                },
          );
          return;
        }
        writeCache(h);
        setState({ ...initial, ...b, loading: false, error: false, stale: false, message: "", log: "" });
      })
      .catch((e) => {
        if (!live) return;
        const msg = String(e?.message ?? e);
        setState((p) =>
          p.movies.length
            ? { ...p, loading: false, stale: true } // داده‌ی قدیمی هست؛ بدون مزاحمت ادامه بده
            : { ...p, loading: false, error: true, message: msg.slice(0, 200), log: mkLog({ result: "error", error: msg }) },
        );
      });
    return () => { live = false; };
  }, [tick]);

  const reload = useCallback(() => {
    setState((p) => ({ ...p, loading: !p.movies.length, error: false, message: "", log: "" }));
    setTick((t) => t + 1);
  }, []);

  const value = useMemo<Catalog>(() => ({ ...state, reload }), [state, reload]);
  return (
    <Ctx.Provider value={value}>
      {children}
      {state.message && <DebugBanner message={state.message} log={state.log} />}
    </Ctx.Provider>
  );
}
