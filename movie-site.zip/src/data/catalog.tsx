import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { fetchHome, toMovie } from "../lib/api";
import type { Movie } from "./movies";

interface Catalog {
  movies: Movie[]; heroSlides: Movie[]; top10: Movie[]; trending: Movie[];
  newReleases: Movie[]; seriesList: Movie[]; loading: boolean; error: boolean;
}
const Ctx = createContext<Catalog>({
  movies: [], heroSlides: [], top10: [], trending: [], newReleases: [],
  seriesList: [], loading: true, error: false,
});
export const useCatalog = () => useContext(Ctx);

export function CatalogProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Catalog>({ ...useContext(Ctx) });
  useEffect(() => {
    fetchHome()
      .then((h) => {
        const m = h.movies.map((i) => toMovie(i, "movie"));
        const s = h.series.map((i) => toMovie(i, "series"));
        const tm = h.topMovies.map((i) => toMovie(i, "movie"));
        const seen = new Set<number>();
        const all = [...m, ...s, ...tm, ...h.topSeries.map((i) => toMovie(i, "series"))]
          .filter((x) => !seen.has(x.id) && seen.add(x.id));
        setState({
          movies: all, heroSlides: m.filter((x) => x.poster).slice(0, 3),
          top10: (tm.length ? tm : m).slice(0, 10), trending: m.slice(0, 12),
          newReleases: m, seriesList: s, loading: false, error: false,
        });
      })
      .catch(() => setState((p) => ({ ...p, loading: false, error: true })));
  }, []);
  const v = useMemo(() => state, [state]);
  return <Ctx.Provider value={v}>{children}</Ctx.Provider>;
}
