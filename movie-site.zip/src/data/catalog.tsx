import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { API_BASE, fetchHome, toMovie } from "../lib/api";
import type { Movie } from "./movies";

interface Catalog {
  movies: Movie[]; heroSlides: Movie[]; top10: Movie[]; trending: Movie[];
  newReleases: Movie[]; seriesList: Movie[]; loading: boolean; error: boolean; message: string;
}
const initial: Catalog = {
  movies: [], heroSlides: [], top10: [], trending: [], newReleases: [],
  seriesList: [], loading: true, error: false, message: "",
};
const Ctx = createContext<Catalog>(initial);
export const useCatalog = () => useContext(Ctx);

export function CatalogProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Catalog>(initial);
  useEffect(() => {
    fetchHome()
      .then((h) => {
        const m = h.movies.map((i) => toMovie(i, "movie"));
        const s = h.series.map((i) => toMovie(i, "series"));
        const tm = h.topMovies.map((i) => toMovie(i, "movie"));
        const seen = new Set<number>();
        const all = [...m, ...s, ...tm, ...h.topSeries.map((i) => toMovie(i, "series"))]
          .filter((x) => !seen.has(x.id) && seen.add(x.id));
        setState({
          movies: all, heroSlides: m.filter((x) => x.poster).slice(0, 3),
          top10: (tm.length ? tm : m).slice(0, 10), trending: m.slice(0, 12),
          newReleases: m, seriesList: s, loading: false, error: false,
          message: all.length
            ? ""
            : `ووکر جواب داد ولی همه لیست‌ها خالی‌اند (فیلم ${h.movies.length}، سریال ${h.series.length}). مشکل از پروکسی/کوکی/سایت مبدا است.`,
        });
      })
      .catch((e) => setState((p) => ({ ...p, loading: false, error: true, message: String(e?.message ?? e) })));
  }, []);
  const v = useMemo(() => state, [state]);
  return (
    <Ctx.Provider value={v}>
      {children}
      {state.message && (
        <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 99999, background: "#7f1d1d", color: "#fff", padding: "10px 12px", fontSize: 12, direction: "ltr", textAlign: "left", wordBreak: "break-all" }}>
          ⚠ {state.message}
          <br />
          API: {API_BASE || "(VITE_API_BASE خالیه!)"}
        </div>
      )}
    </Ctx.Provider>
  );
}
